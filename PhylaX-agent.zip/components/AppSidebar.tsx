"use client";

import { Plus, MessageSquare, Trash2, Bot, BarChart3, Settings, Moon, Sun } from "lucide-react";
import Image from "next/image";

export interface ChatSession {
  id: string;
  label: string;
  createdAt: number;
}

export type SidebarView = "agent" | "portfolio" | "settings";

interface Props {
  sessions: ChatSession[];
  activeSessionId: string;
  activeView: SidebarView;
  onNewChat: () => void;
  onSelectSession: (id: string) => void;
  onDeleteSession: (id: string) => void;
  onChangeView: (view: SidebarView) => void;
}

const BG = "oklch(0.13 0.03 265)";
const PILL_ACTIVE = "oklch(1 0 0 / 0.08)";
const PILL_HOVER = "oklch(1 0 0 / 0.04)";
const TEXT_ACTIVE = "oklch(0.98 0 0)";
const TEXT_MUTED = "oklch(1 0 0 / 0.45)";
const TEXT_LABEL = "oklch(1 0 0 / 0.25)";
const DIVIDER = "oklch(1 0 0 / 0.07)";

export function AppSidebar({
  sessions,
  activeSessionId,
  activeView,
  onNewChat,
  onSelectSession,
  onDeleteSession,
  onChangeView,
}: Props) {
  return (
    <aside
      className="flex flex-col h-full w-full overflow-hidden"
      style={{ background: BG }}
    >
      {/* ── Brand header ── */}
      <div className="px-5 pt-6 pb-5" style={{ borderBottom: `1px solid ${DIVIDER}` }}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 shrink-0 flex items-center justify-center">
            <Image
              src="/assets/PhylaX-mark.png"
              alt="PhylaX"
              width={36}
              height={36}
              className="object-contain"
              style={{ filter: "drop-shadow(0 0 8px oklch(0.62 0.19 260 / 0.6))" }}
              priority
            />
          </div>
          <div>
            <p className="text-[15px] font-bold tracking-tight text-white leading-none">
              Phyla<span
                style={{
                  background: "linear-gradient(135deg, oklch(0.75 0.19 260), oklch(0.82 0.11 220))",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >X</span>
            </p>
            <p
              className="text-[9px] uppercase tracking-[0.18em] font-semibold mt-0.5"
              style={{ color: TEXT_LABEL }}
            >
              DeFi Guard Agent
            </p>
          </div>
        </div>
      </div>

      {/* ── Main nav ── */}
      <div className="px-3 pt-4 pb-2 space-y-0.5">
        {[
          { icon: Bot, label: "Agent", view: "agent" as SidebarView },
          { icon: BarChart3, label: "Portfolio", view: "portfolio" as SidebarView },
          { icon: Settings, label: "Settings", view: "settings" as SidebarView },
        ].map(({ icon: Icon, label, view }) => {
          const active = activeView === view;
          return (
            <button
              key={view}
              onClick={() => onChangeView(view)}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl text-sm font-medium transition-all duration-200 text-left hover:translate-x-1 group"
              style={{
                background: active ? PILL_ACTIVE : "transparent",
                color: active ? TEXT_ACTIVE : TEXT_MUTED,
              }}
              onMouseEnter={e => { if (!active) e.currentTarget.style.background = PILL_HOVER; e.currentTarget.style.color = TEXT_ACTIVE; }}
              onMouseLeave={e => { if (!active) { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = TEXT_MUTED; } }}
            >
              <Icon
                className="shrink-0 transition-transform duration-200 group-hover:scale-110"
                style={{
                  width: 18,
                  height: 18,
                  color: active ? "oklch(0.75 0.19 260)" : "inherit",
                }}
              />
              {label}
            </button>
          );
        })}
      </div>

      {/* ── Sessions (agent view only) ── */}
      {activeView === "agent" && (
        <>
          <div className="px-3 pt-3 pb-2">
            <button
              onClick={() => { onNewChat(); onChangeView("agent"); }}
              className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-2xl text-sm font-medium transition-all duration-150 group"
              style={{
                background: PILL_ACTIVE,
                color: TEXT_MUTED,
                border: `1px solid oklch(1 0 0 / 0.06)`,
              }}
            >
              <Plus
                style={{ width: 16, height: 16, color: "inherit" }}
                className="transition-transform duration-300 group-hover:rotate-90"
              />
              New Chat
            </button>
          </div>

          <div className="px-5 pt-2 pb-1.5">
            <p
              className="text-[9px] font-bold uppercase tracking-[0.2em]"
              style={{ color: TEXT_LABEL }}
            >
              Sessions
            </p>
          </div>

          <div className="flex-1 overflow-y-auto px-3 pb-4 space-y-0.5">
            {sessions.length === 0 && (
              <div className="flex flex-col items-center py-8 gap-2">
                <MessageSquare style={{ width: 18, height: 18, color: TEXT_LABEL }} />
                <p className="text-[10px]" style={{ color: TEXT_LABEL }}>No sessions yet</p>
              </div>
            )}
            {sessions.map((session) => {
              const isActive = session.id === activeSessionId && activeView === "agent";
              return (
                <div
                  key={session.id}
                  className="group flex items-center gap-2.5 px-3 py-2.5 rounded-2xl cursor-pointer transition-all duration-200 hover:translate-x-1"
                  style={{
                    background: isActive ? PILL_ACTIVE : "transparent",
                    color: isActive ? TEXT_ACTIVE : TEXT_MUTED,
                  }}
                  onMouseEnter={e => { if (!isActive) { e.currentTarget.style.background = PILL_HOVER; e.currentTarget.style.color = TEXT_ACTIVE; } }}
                  onMouseLeave={e => { if (!isActive) { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = TEXT_MUTED; } }}
                  onClick={() => { onSelectSession(session.id); onChangeView("agent"); }}
                >
                  <MessageSquare
                    style={{
                      width: 15,
                      height: 15,
                      color: isActive ? "oklch(0.75 0.19 260)" : TEXT_MUTED,
                      flexShrink: 0,
                    }}
                  />
                  <span className="flex-1 text-[12px] font-medium truncate">
                    {session.label || "New chat"}
                  </span>
                  <button
                    onClick={(e) => { e.stopPropagation(); onDeleteSession(session.id); }}
                    className="opacity-0 group-hover:opacity-100 p-1 rounded-lg transition-all duration-150 shrink-0 hover:bg-red-500/20"
                    style={{ color: TEXT_MUTED }}
                    onMouseEnter={e => { e.currentTarget.style.color = "oklch(0.65 0.2 20)"; }}
                    onMouseLeave={e => { e.currentTarget.style.color = TEXT_MUTED; }}
                    aria-label={`Delete ${session.label}`}
                  >
                    <Trash2 style={{ width: 13, height: 13 }} className="transition-transform duration-200 hover:scale-110" />
                  </button>
                </div>
              );
            })}
          </div>
        </>
      )}

      {activeView !== "agent" && <div className="flex-1" />}

      {/* ── Footer ── */}
      <div
        className="px-5 py-4 flex flex-col gap-3"
        style={{ borderTop: `1px solid ${DIVIDER}` }}
      >
        {/* Footer row: Live Badge & Theme Toggle */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75 animate-ping" />
              <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-400" />
            </span>
            <span
              className="text-[10px] font-semibold uppercase tracking-[0.15em]"
              style={{ color: TEXT_LABEL }}
            >
              X Layer Live
            </span>
          </div>

          <button
            onClick={() => {
              document.documentElement.classList.toggle('dark');
            }}
            className="p-1.5 rounded-lg hover:bg-white/10 transition-colors text-muted-foreground hover:text-white"
            title="Toggle Dark Mode"
          >
            <Moon className="w-4 h-4 hidden dark:block" />
            <Sun className="w-4 h-4 block dark:hidden" />
          </button>
        </div>
      </div>
    </aside>
  );
}
