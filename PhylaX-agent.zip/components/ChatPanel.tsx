"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import {
  Send,
  Shield,
  Scan,
  Eye,
  BarChart3,
  Search,
  Wallet,
  Bot,
} from "lucide-react";
import { ChatMessage, type ChatMessageData } from "./ChatMessage";
import { TradePlanCard } from "./TradePlanCard";
import { RiskResultCard } from "./RiskResultCard";
import { QuoteCard } from "./QuoteCard";
import type { ChatState } from "../lib/chat-states";
import { CHAT_STATE_LABELS, isBusyState } from "../lib/chat-states";
import type { TokenSignal, SimulationResult } from "../lib/schemas";
import { type ChainConfig } from "../lib/chains";

// ─── Pipeline types ───────────────────────────────────────────────────────────

interface TradePlanData { type: "trade-plan"; signals: TokenSignal[]; chainName: string; source: string; }
interface RiskResultData { type: "risk-result"; tokenSymbol: string; tokenAddress: string; riskLevel: "safe" | "high_risk" | "unknown" | "skipped" | "pending"; riskDetails?: string; source: string; }
interface QuoteData { type: "quote"; quote: SimulationResult; fromSymbol: string; toSymbol: string; amount: number; scanDecision: string; source: string; approvalId?: string; tokenAddress?: string; targetWalletAddress?: string; needsApproval?: boolean; approveTxData?: any; }
type PipelineData = TradePlanData | RiskResultData | QuoteData;
interface ChatMessageWithCards extends ChatMessageData { pipelineData?: PipelineData | null; }

// ─── Prompt suggestions ───────────────────────────────────────────────────────

const SUGGESTIONS = [
  { icon: Eye, label: "Swap Preview", desc: "Swap 50 USDC → OKB on X Layer", prompt: "Swap 50 USDC to OKB on X Layer" },
  { icon: Scan, label: "Safety Scan", desc: "Is this token safe to trade?", prompt: "Scan OKB for honeypot and rug risk on X Layer" },
  { icon: Search, label: "Trending Now", desc: "What's hot on X Layer right now?", prompt: "What tokens are trending on X Layer right now?" },
  { icon: BarChart3, label: "Market Read", desc: "Check smart money positioning", prompt: "What's the current market structure for ETH?" },
];

// ─── Props ────────────────────────────────────────────────────────────────────

interface ChatPanelProps {
  conversationId: string;
  isAuthenticated: boolean;
  hasWallet: boolean;
  onConnectWallet: () => void;
  onSignIn: () => void;
  onRenameSession?: (label: string) => void;
  onCreateSession?: () => Promise<string | undefined>;
  walletAddress?: string | null;
  getAccessToken?: () => Promise<string | null>;
  getIdentityToken?: () => Promise<string | null>;
  selectedChain: ChainConfig;
}

// ─── Pipeline card wrapper with entrance animation ────────────────────────────

function PipelineCardWrapper({ children }: { children: React.ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    requestAnimationFrame(() => {
      el.style.opacity = "1";
      el.style.transform = "translateY(0)";
    });
  }, []);
  return (
    <div
      ref={ref}
      style={{
        opacity: 0,
        transform: "translateY(6px)",
        transition: "opacity 0.25s cubic-bezier(0.22, 1, 0.36, 1) 0.1s, transform 0.25s cubic-bezier(0.22, 1, 0.36, 1) 0.1s",
      }}
    >
      {children}
    </div>
  );
}

// ─── Empty-state wrapper with fade-in ─────────────────────────────────────────

function EmptyStateWrapper({ children }: { children: React.ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    requestAnimationFrame(() => {
      el.style.opacity = "1";
      el.style.transform = "translateY(0)";
    });
  }, []);
  return (
    <div
      ref={ref}
      style={{
        opacity: 0,
        transform: "translateY(10px)",
        transition: "opacity 0.3s cubic-bezier(0.22, 1, 0.36, 1), transform 0.3s cubic-bezier(0.22, 1, 0.36, 1)",
      }}
    >
      {children}
    </div>
  );
}

// ─── Component ────────────────────────────────────────────────────────────────

export function ChatPanel({
  conversationId,
  isAuthenticated,
  hasWallet,
  onConnectWallet,
  onSignIn,
  onRenameSession,
  onCreateSession,
  walletAddress,
  getAccessToken,
  getIdentityToken,
  selectedChain,
}: ChatPanelProps) {
  const [messages, setMessages] = useState<ChatMessageWithCards[]>([]);
  const [input, setInput] = useState("");
  const [chatState, setChatState] = useState<ChatState>(
    isAuthenticated ? "WALLET_CONNECTED" : "WALLET_REQUIRED"
  );
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const canChat = isAuthenticated; // email login is enough for chat
  const prevAuthenticated = useRef(isAuthenticated);
  const hasRenamed = useRef(false);
  const hasMessages = messages.length > 0;

  const [isFetchingMessages, setIsFetchingMessages] = useState(false);

  // ── Fetch messages ──────────────────────────────────────────────────
  useEffect(() => {
    if (!isAuthenticated || !conversationId || conversationId.startsWith("session-")) {
      return;
    }

    let ignore = false;
    setTimeout(() => setIsFetchingMessages(true), 0);

    const runFetch = async () => {
      try {
        const token = getAccessToken ? await getAccessToken() : null;
        const res = await fetch(`/api/chat/sessions/${conversationId}/messages`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();
        
        if (!ignore && data.messages) {
          setMessages(data.messages.map((m: { id: string; role: string; content: string; createdAt: string; metadata: Record<string, unknown> | null }) => ({
            id: m.id,
            role: m.role as "user" | "assistant" | "system",
            content: m.content,
            timestamp: new Date(m.createdAt).getTime(),
            pipelineData: (m.metadata as unknown as PipelineData) || null,
          })));
          
          if (data.messages.length > 0) {
            hasRenamed.current = true;
            setChatState("WALLET_CONNECTED");
          }
        }
      } catch (err) {
        console.error("Failed to fetch messages:", err);
      } finally {
        if (!ignore) setIsFetchingMessages(false);
      }
    };

    runFetch();
    return () => { ignore = true; };
  }, [isAuthenticated, conversationId, getAccessToken]);

  useEffect(() => {
    if (isAuthenticated && !prevAuthenticated.current && messages.length === 0 && !isFetchingMessages) {
      // Signed in — show welcome only if no messages
      queueMicrotask(() => {
        setChatState("WALLET_CONNECTED");
        setMessages(prev => {
          if (prev.length > 0) return prev;
          return [...prev, {
            id: `system-welcome-${Date.now()}`,
            role: "assistant",
            content: `PhylaX is ready on ${selectedChain.name}.
I can scan tokens, search for signals, and prepare quotes. Every trade requires your wallet signature.`,
            timestamp: Date.now(),
          }];
        });
      });
    } else if (!isAuthenticated && prevAuthenticated.current) {
      // Signed out — reset to welcome state
      setMessages([]);
      setChatState("WALLET_REQUIRED");
      setInput("");
      setIsLoading(false);
      hasRenamed.current = false;
    }
    prevAuthenticated.current = isAuthenticated;
  }, [isAuthenticated, hasWallet, selectedChain.name, messages.length, isFetchingMessages]);

  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  // ── Send message ──────────────────────────────────────────────────────

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim() || !canChat || isLoading) return;
    
    let targetConversationId = conversationId;
    if (!targetConversationId || targetConversationId.startsWith("session-")) {
      if (onCreateSession) {
        setIsLoading(true);
        try {
          const newId = await onCreateSession();
          if (newId) targetConversationId = newId;
        } catch (err) {
          console.error("Failed to implicitly create session:", err);
        }
      }
      
      if (!targetConversationId || targetConversationId.startsWith("session-")) {
        setMessages(prev => [...prev, {
          id: `system-error-${Date.now()}`,
          role: "system",
          content: "Session is still initializing. Please wait a moment and try again.",
          timestamp: Date.now(),
        }]);
        setIsLoading(false);
        return;
      }
    }

    const trimmedText = text.trim();
    // Auto-rename session on first user message
    if (!hasRenamed.current && onRenameSession) {
      hasRenamed.current = true;
      onRenameSession(trimmedText);
    }
    const userMsg: ChatMessageWithCards = { id: `user-${Date.now()}`, role: "user", content: trimmedText, timestamp: Date.now() };
    const loadingMsg: ChatMessageWithCards = { id: `assistant-loading-${Date.now()}`, role: "assistant", content: "", timestamp: Date.now(), isLoading: true };
    setMessages(prev => [...prev, userMsg, loadingMsg]);
    setInput(""); setIsLoading(true); setChatState("UNDERSTANDING_INTENT");
    try {
      let authToken = "client-token"; let identityToken: string | null = null;
      if (getAccessToken) { try { const t = await getAccessToken(); if (t) authToken = t; } catch { /* */ } }
      if (getIdentityToken) { try { identityToken = await getIdentityToken(); } catch { /* */ } }
      const headers: Record<string, string> = { "Content-Type": "application/json", "Authorization": `Bearer ${authToken}`, "x-wallet-address": walletAddress ?? "" };
      if (identityToken) headers["x-privy-identity-token"] = identityToken;
      
      const res = await fetch("/api/chat/stream", { method: "POST", headers, body: JSON.stringify({ conversationId: targetConversationId, message: text.trim(), chain: selectedChain.id }) });
      
      if (!res.ok) {
        let errorContent = "Something went wrong. Please try again.";
        try {
          const data = await res.json();
          errorContent = data.error ?? errorContent;
        } catch { /* */ }
        if (res.status === 401) errorContent = errorContent.includes("expired") ? "Session expired. Please reconnect your wallet." : errorContent;
        else if (res.status === 403) errorContent = "Wallet mismatch. Please reconnect.";
        setMessages(prev => prev.map(m => m.id === loadingMsg.id ? { ...m, isLoading: false, content: errorContent, role: "system" as const } : m));
        setChatState("FAILED"); return;
      }

      const contentType = res.headers.get("content-type");
      if (contentType && contentType.includes("text/event-stream")) {
        const reader = res.body?.getReader();
        if (!reader) throw new Error("No reader available");
        const decoder = new TextDecoder();
        let buffer = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          
          let newlineIndex;
          while ((newlineIndex = buffer.indexOf("\n\n")) >= 0) {
            const chunk = buffer.slice(0, newlineIndex);
            buffer = buffer.slice(newlineIndex + 2);
            
            if (chunk.startsWith("event: ")) {
              const eventTypeLine = chunk.split("\n")[0];
              const dataLine = chunk.split("\n").find(l => l.startsWith("data: "));
              if (!dataLine) continue;
              
              const type = eventTypeLine.replace("event: ", "").trim();
              const data = JSON.parse(dataLine.replace("data: ", ""));
              
              if (type === "step" || type === "tool_start" || type === "tool_result" || type === "partial_failure") {
                setMessages(prev => prev.map(m => {
                  if (m.id === loadingMsg.id) {
                    const currentSteps = m.steps ? [...m.steps] : [];
                    const stepId = data.id || `step-${Date.now()}`;
                    const existingIdx = currentSteps.findIndex(s => s.id === stepId);
                    
                    if (existingIdx >= 0) {
                      currentSteps[existingIdx] = { ...currentSteps[existingIdx], status: data.status, label: data.label || currentSteps[existingIdx].label };
                    } else {
                      currentSteps.push({ id: stepId, label: data.label, status: data.status });
                    }
                    return { ...m, steps: currentSteps };
                  }
                  return m;
                }));
              } else if (type === "final") {
                setMessages(prev => prev.map(m => m.id === loadingMsg.id ? { ...m, isLoading: false, content: data.agentMessage ?? "Done.", pipelineData: data.pipelineData ?? null } : m));
                if (data.chatState) setChatState(data.chatState as ChatState);
              } else if (type === "error") {
                throw new Error(data.error);
              }
            }
          }
        }
      } else {
        const data = await res.json();
        const newState: ChatState = data.chatState ?? "WALLET_CONNECTED";
        setMessages(prev => prev.map(m => m.id === loadingMsg.id ? { ...m, isLoading: false, content: data.agentMessage ?? "Done.", pipelineData: data.pipelineData ?? null } : m));
        setChatState(newState);
      }
    } catch {
      setMessages(prev => prev.map(m => m.id === loadingMsg.id ? { ...m, isLoading: false, content: "Network error. Check your connection.", role: "system" as const } : m));
      setChatState("FAILED");
    } finally { setIsLoading(false); }
  }, [canChat, isLoading, walletAddress, getAccessToken, getIdentityToken, onRenameSession, selectedChain.id, conversationId]);

  const handleSuggestionClick = (prompt: string) => {
    if (!canChat) { onSignIn(); return; }
    sendMessage(prompt);
  };
  const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); sendMessage(input); };
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(input); }
  };

  const renderPipelineCard = (data: PipelineData) => {
    switch (data.type) {
      case "trade-plan": return <TradePlanCard tokens={data.signals} chainName={data.chainName} />;
      case "risk-result": return <RiskResultCard tokenSymbol={data.tokenSymbol} tokenAddress={data.tokenAddress} riskLevel={data.riskLevel} details={data.riskDetails} />;
      case "quote": return <QuoteCard quote={data.quote} fromSymbol={data.fromSymbol} toSymbol={data.toSymbol} approvalId={data.approvalId} showExecute={!!data.approvalId} getAccessToken={getAccessToken} getIdentityToken={getIdentityToken} walletAddress={walletAddress} targetWalletAddress={data.targetWalletAddress} onConnectWallet={onConnectWallet} amount={data.amount} tokenAddress={data.tokenAddress} scanDecision={data.scanDecision} chainConfig={selectedChain} needsApproval={data.needsApproval} approveTxData={data.approveTxData} />;
      default: return null;
    }
  };

  // ─── Render ─────────────────────────────────────────────────────────────

  return (
    <div className="flex flex-col h-full min-h-0">
      {hasMessages ? (
        /* ═══ CONVERSATION MODE ═══ */
        <>
          <div className="flex-1 overflow-y-auto scroll-contain min-h-0">
            <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6 space-y-5">
              {messages.map(msg => (
                <div key={msg.id} className="space-y-3">
                  <ChatMessage message={msg} />
                  {msg.pipelineData && msg.role === "assistant" && !msg.isLoading && (
                    <PipelineCardWrapper>
                      {renderPipelineCard(msg.pipelineData)}
                    </PipelineCardWrapper>
                  )}
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          </div>

          {/* Pinned input */}
          <div className="shrink-0 border-t border-border/40 bg-white px-4 sm:px-6 py-3">
            <div className="max-w-3xl mx-auto">
              <form onSubmit={handleSubmit}>
                <div className="flex items-end gap-2 rounded-2xl border border-border bg-muted/20 px-4 py-3 focus-within:border-electric/40 focus-within:bg-white focus-within:shadow-soft transition-all duration-200">
                  <textarea ref={inputRef} value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKeyDown} disabled={isLoading} placeholder="Ask PhylaX anything…" rows={1} className="flex-1 bg-transparent text-[15px] text-foreground placeholder:text-muted-foreground/40 resize-none outline-none min-h-[28px] max-h-[150px]" />
                  <button type="submit" disabled={!input.trim() || isLoading} aria-label="Send" className={`p-2 rounded-xl transition-all duration-150 flex-shrink-0 ${input.trim() && !isLoading ? "bg-gradient-brand text-white hover:shadow-glow" : "bg-muted/60 text-muted-foreground/30 cursor-not-allowed"}`}>
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </form>
              {isBusyState(chatState) && (
                <p className="text-[11px] text-electric font-medium text-center mt-2 animate-pulse">{CHAT_STATE_LABELS[chatState]}</p>
              )}
              <p className="text-[10px] text-muted-foreground/30 text-center mt-2">Non-custodial · User-signed execution · {selectedChain.name}</p>
            </div>
          </div>
        </>
      ) : (
        /* ═══ EMPTY STATE ═══ */
        <div className="flex-1 flex flex-col items-center justify-center px-4 sm:px-6">
          <div className="w-full max-w-2xl mx-auto">

            {/* Hero mark + tagline */}
            <EmptyStateWrapper>
              <div className="text-center mb-10 flex flex-col items-center">
                {/* Premium Glowing Avatar */}
                <div className="relative inline-flex items-center justify-center mb-8">
                  {/* Outer pulse */}
                  <div className="absolute inset-0 rounded-full blur-[32px] opacity-30 animate-pulse" style={{ background: "linear-gradient(135deg, oklch(0.62 0.19 260), oklch(0.4 0.25 280))" }} />
                  {/* Inner glow */}
                  <div className="absolute inset-0 rounded-full blur-xl opacity-60" style={{ background: "linear-gradient(135deg, oklch(0.62 0.19 260), oklch(0.7 0.13 280))" }} />
                  {/* Glass shell */}
                  <div className="relative w-24 h-24 rounded-full flex items-center justify-center backdrop-blur-md border border-white/20 shadow-2xl" style={{ background: "oklch(1 0 0 / 0.1)", boxShadow: "0 0 40px oklch(0.62 0.19 260 / 0.2) inset" }}>
                    <div className="w-20 h-20 rounded-full flex items-center justify-center bg-gradient-brand shadow-inner">
                      <Bot className="w-10 h-10 text-white" />
                    </div>
                  </div>
                </div>

                <h2 className="text-3xl sm:text-4xl font-display font-extrabold tracking-tight mb-3">
                  <span className="text-transparent bg-clip-text bg-gradient-brand">PhylaX Agent</span>
                </h2>
                <p className="text-[14px] sm:text-[15px] text-muted-foreground max-w-sm mx-auto leading-relaxed">
                  Your Tier-1 DeFi guard. Every trade scanned. Every quote guarded. Your wallet always signs.
                </p>

                {/* Trust badges */}
                <div className="flex items-center justify-center gap-3 mt-6 flex-wrap">
                  {["Dual token scan", "No-broadcast", "OKX powered"].map((badge) => (
                    <span
                      key={badge}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest shadow-sm backdrop-blur-sm"
                      style={{
                        background: "linear-gradient(180deg, oklch(1 0 0 / 0.8), oklch(0.98 0.01 260))",
                        color: "oklch(0.5 0.15 260)",
                        border: "1px solid oklch(0.62 0.19 260 / 0.15)",
                      }}
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-electric inline-block animate-pulse" />
                      {badge}
                    </span>
                  ))}
                </div>
              </div>
            </EmptyStateWrapper>

            {/* Glassmorphic Suggestion cards */}
            <EmptyStateWrapper>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6 w-full">
                {SUGGESTIONS.map(s => (
                  <button
                    type="button"
                    key={s.prompt}
                    onClick={() => handleSuggestionClick(s.prompt)}
                    disabled={isLoading}
                    className="group relative overflow-hidden text-left rounded-[20px] p-4 transition-all duration-300 hover:-translate-y-1"
                    style={{ 
                      background: "linear-gradient(135deg, oklch(1 0 0 / 0.9) 0%, oklch(0.98 0.01 260 / 0.6) 100%)",
                      border: "1px solid oklch(0.62 0.19 260 / 0.1)",
                      boxShadow: "0 4px 20px oklch(0.62 0.19 260 / 0.03)"
                    }}
                    onMouseEnter={e => {
                      (e.currentTarget as HTMLButtonElement).style.borderColor = "oklch(0.62 0.19 260 / 0.4)";
                      (e.currentTarget as HTMLButtonElement).style.boxShadow = "0 8px 30px oklch(0.62 0.19 260 / 0.15)";
                    }}
                    onMouseLeave={e => {
                      (e.currentTarget as HTMLButtonElement).style.borderColor = "oklch(0.62 0.19 260 / 0.1)";
                      (e.currentTarget as HTMLButtonElement).style.boxShadow = "0 4px 20px oklch(0.62 0.19 260 / 0.03)";
                    }}
                  >
                    {/* Hover glow effect inside card */}
                    <div className="absolute inset-0 bg-gradient-to-br from-electric/0 via-electric/5 to-electric/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    
                    <div className="relative z-10 flex items-center gap-3 mb-2">
                      <div
                        className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 shadow-inner"
                        style={{ background: "linear-gradient(135deg, oklch(0.62 0.19 260 / 0.15), oklch(0.62 0.19 260 / 0.05))" }}
                      >
                        <s.icon className="w-4 h-4 text-electric" />
                      </div>
                      <span className="text-[13px] font-bold text-foreground">{s.label}</span>
                    </div>
                    <p className="text-[11px] text-muted-foreground leading-relaxed pl-8">{s.desc}</p>
                  </button>
                ))}
              </div>
            </EmptyStateWrapper>

            {/* Input or Sign In Button */}
            {!canChat ? (
              <div className="flex justify-center mt-6">
                <button
                  type="button"
                  onClick={onConnectWallet}
                  className="inline-flex items-center gap-2 rounded-2xl bg-gradient-brand text-white px-8 py-3.5 text-[14px] font-bold shadow-soft hover:shadow-glow transition-all duration-200 hover:scale-[1.02] hover:-translate-y-0.5"
                >
                  <Wallet className="w-4 h-4" />
                  Sign in to start trading
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit}>
                <div
                  className="flex items-end gap-2 rounded-2xl border px-4 py-3 transition-all duration-200"
                  style={{
                    borderColor: "oklch(0.92 0.01 260)",
                    background: "oklch(0.975 0.005 250 / 0.5)",
                  }}
                  onFocus={e => { (e.currentTarget as HTMLDivElement).style.borderColor = "oklch(0.62 0.19 260 / 0.5)"; }}
                  onBlur={e => { (e.currentTarget as HTMLDivElement).style.borderColor = "oklch(0.92 0.01 260)"; }}
                >
                  <textarea
                    ref={inputRef}
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    disabled={isLoading}
                    placeholder="Ask PhylaX — swap, scan, signal…"
                    rows={1}
                    className="flex-1 bg-transparent text-[15px] text-foreground placeholder:text-muted-foreground/40 resize-none outline-none disabled:cursor-not-allowed min-h-[28px] max-h-[150px]"
                  />
                  <button
                    type="submit"
                    disabled={!input.trim() || isLoading}
                    aria-label="Send"
                    className="p-2 rounded-xl transition-all duration-150 flex-shrink-0"
                    style={{
                      background: input.trim() && !isLoading
                        ? "linear-gradient(135deg, oklch(0.62 0.19 260), oklch(0.7 0.13 280))"
                        : "oklch(0.92 0.01 260)",
                      color: input.trim() && !isLoading ? "white" : "oklch(0.7 0.01 260)",
                    }}
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}

            <p className="text-[10px] text-muted-foreground/30 text-center mt-3 tracking-wide">
              Non-custodial · User-signed · X Layer
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
