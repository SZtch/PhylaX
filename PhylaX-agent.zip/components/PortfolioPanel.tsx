"use client";

import { useState, useRef, useEffect } from "react";
import {
  Wallet,
  Clock,
  Plus,
  Search,
  ChevronDown,
  X,
  Coins,
  RefreshCw,
  ExternalLink,
} from "lucide-react";
import { CopyAddress } from "./CopyAddress";
import { createPublicClient, http, erc20Abi, formatUnits } from "viem";
import { subscribeTxs, type TxRecord } from "../lib/tx-store";

// ─── Types ────────────────────────────────────────────────────────────────────

interface Props {
  isAuthenticated: boolean;
  hasWallet: boolean;
  walletAddress?: string | null;
  chainName: string;
  executionMode: string;
  onConnectWallet: () => void;
  onSignIn: () => void;
}

type TimeSpan = "1D" | "1W" | "1M";
type Currency = "USD" | "EUR" | "GBP";

// ─── X Layer assets with real addresses ────────────────────────────────────────

const POPULAR_ASSETS = [
  { symbol: "OKB", name: "OKB", color: "#000", isNative: true, decimals: 18 },
  { symbol: "ETH", name: "Ethereum", color: "#627EEA", address: "0x5a77f1443d16ee5761d310e38b62f77f726bc71c", decimals: 18 },
  { symbol: "USDC", name: "USD Coin", color: "#2775CA", address: "0x74b7f16337b8972027f6196a17a631ac6de26d22", decimals: 6 },
  { symbol: "USDT", name: "Tether", color: "#26A17B", address: "0x1e4a5963abfd975d8c9021ce480b42188849d41d", decimals: 6 },
  { symbol: "WBTC", name: "Wrapped Bitcoin", color: "#F7931A", address: "0x12bb890508c125661e03b09ecc9860dd3081b0a8", decimals: 8 },
];

const publicClient = createPublicClient({
  transport: http("https://rpc.xlayer.tech")
});

// ─── Component ────────────────────────────────────────────────────────────────

export function PortfolioPanel({
  isAuthenticated,
  hasWallet,
  walletAddress,
  chainName,
  onConnectWallet,
  onSignIn,
}: Props) {
  const [timeSpan, setTimeSpan] = useState<TimeSpan>("1D");
  const [currency, setCurrency] = useState<Currency>("USD");
  const [currencyOpen, setCurrencyOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showHistory, setShowHistory] = useState(false);
  const [showAddCoin, setShowAddCoin] = useState(false);
  const [txRecords, setTxRecords] = useState<TxRecord[]>([]);
  const [addCoinInput, setAddCoinInput] = useState("");
  const [addedCoins, setAddedCoins] = useState<string[]>([]);
  const [balances, setBalances] = useState<Record<string, string>>({});
  const [prices, setPrices] = useState<Record<string, Record<string, number>>>({});
  const [isFetchingBalances, setIsFetchingBalances] = useState(false);
  const currencyRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!currencyOpen) return;
    function handleClickOutside(e: MouseEvent) {
      if (currencyRef.current && !currencyRef.current.contains(e.target as Node)) setCurrencyOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [currencyOpen]);

  // Subscribe to tx-store so confirmed trades show up immediately
  useEffect(() => {
    const unsub = subscribeTxs((txs) => setTxRecords(txs));
    return unsub;
  }, []);

  // Fetch persisted tx history from DB on mount and wallet change
  useEffect(() => {
    if (!walletAddress || !hasWallet) return;
    fetch(`/api/tx-history?wallet=${walletAddress.toLowerCase()}`)
      .then((r) => r.json())
      .then((data: { txs?: TxRecord[] }) => {
        if (Array.isArray(data.txs) && data.txs.length > 0) {
          // Merge DB records with in-memory store, dedupe by txHash
          setTxRecords((current) => {
            const seen = new Set(current.map((t) => t.txHash));
            const fresh = data.txs!.filter((t) => !seen.has(t.txHash));
            return [...current, ...fresh].sort(
              (a, b) => new Date(b.confirmedAt).getTime() - new Date(a.confirmedAt).getTime()
            );
          });
        }
      })
      .catch(() => {/* non-fatal */});
  }, [walletAddress, hasWallet]);

  const fetchBalances = async () => {
    if (!walletAddress || !hasWallet) return;
    setIsFetchingBalances(true);
    try {
      const newBalances: Record<string, string> = {};
      
      // Fetch Native OKB
      try {
        const okbBal = await publicClient.getBalance({ address: walletAddress as `0x${string}` });
        newBalances["OKB"] = Number(formatUnits(okbBal, 18)).toFixed(4);
      } catch (e) {
        console.error("Failed to fetch OKB", e);
      }

      // Fetch ERC20s in parallel
      await Promise.all(POPULAR_ASSETS.filter(a => !a.isNative).map(async (asset) => {
        try {
          const bal = await publicClient.readContract({
            address: asset.address as `0x${string}`,
            abi: erc20Abi,
            functionName: 'balanceOf',
            args: [walletAddress as `0x${string}`]
          });
          newBalances[asset.symbol] = Number(formatUnits(bal, asset.decimals)).toFixed(4);
        } catch (e: any) {
          // Suppress "returned no data" errors for unverified/missing contracts on test networks
          if (!e.message?.includes("returned no data")) {
            console.warn(`[Portfolio] Failed to fetch ${asset.symbol}:`, e.message);
          }
        }
      }));

      // Fetch Prices from CoinGecko
      let priceMap: Record<string, Record<string, number>> = {};
      try {
        const cgRes = await fetch("https://api.coingecko.com/api/v3/simple/price?ids=okb,ethereum,usd-coin,tether,wrapped-bitcoin&vs_currencies=usd,eur,gbp");
        if (cgRes.ok) {
          const cgData = await cgRes.json();
          priceMap = {
            "OKB": cgData["okb"] || {},
            "ETH": cgData["ethereum"] || {},
            "USDC": cgData["usd-coin"] || {},
            "USDT": cgData["tether"] || {},
            "WBTC": cgData["wrapped-bitcoin"] || {}
          };
          setPrices(priceMap);
        }
      } catch (e) {
        console.error("Failed to fetch prices", e);
      }

      setBalances(newBalances);
    } catch (err) {
      console.error("Error fetching balances:", err);
    } finally {
      setIsFetchingBalances(false);
    }
  };

  useEffect(() => {
    fetchBalances();
    // Refresh every 30 seconds
    const interval = setInterval(fetchBalances, 30000);
    return () => clearInterval(interval);
  }, [walletAddress, hasWallet]);

  const currencySymbol = currency === "USD" ? "$" : currency === "EUR" ? "€" : "£";
  const currencyKey = currency.toLowerCase();

  // Calculate Total Value
  const totalValue = POPULAR_ASSETS.reduce((acc, asset) => {
    const bal = parseFloat(balances[asset.symbol] || "0");
    const price = prices[asset.symbol]?.[currencyKey] || 0;
    return acc + bal * price;
  }, 0);

  // Not authenticated
  if (!isAuthenticated) {
    return (
      <div className="flex-1 flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 rounded-2xl bg-gradient-brand flex items-center justify-center mx-auto mb-5 shadow-soft">
            <Wallet className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-xl font-display font-bold text-foreground mb-2">Portfolio</h2>
          <p className="text-sm text-muted-foreground mb-5">Sign in to view your wallet and assets.</p>
          <button type="button" onClick={onSignIn} className="inline-flex items-center rounded-full bg-gradient-brand text-white px-6 py-2.5 text-sm font-medium hover:shadow-glow transition-all duration-200 hover:scale-[1.02]">
            Sign in to get started
          </button>
        </div>
      </div>
    );
  }

  const filteredAssets = POPULAR_ASSETS.filter(a =>
    a.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
    a.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex-1 overflow-y-auto scroll-contain">
      <div className="max-w-lg mx-auto px-4 sm:px-6 py-6">

        {/* ═══ HEADER — Total Asset Value ═══ */}
        <div className="text-center mb-6">
          <div className="flex items-center justify-center gap-1.5 mb-1">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/50">
              Total Assets
            </p>
            {/* Currency selector */}
            <div className="relative" ref={currencyRef}>
              <button
                onClick={() => setCurrencyOpen(v => !v)}
                className="inline-flex items-center gap-0.5 text-[11px] font-semibold text-muted-foreground/50 uppercase tracking-wider hover:text-muted-foreground transition-colors"
              >
                ({currency})
                <ChevronDown className={`w-2.5 h-2.5 chevron-rotate ${currencyOpen ? "is-open" : ""}`} />
              </button>
              <div className={`absolute top-full left-1/2 -translate-x-1/2 mt-1 w-20 bg-white border border-border rounded-lg shadow-soft py-0.5 z-50 dropdown-panel ${currencyOpen ? "is-open" : ""}`}>
                {(["USD", "EUR", "GBP"] as Currency[]).map(c => (
                  <button
                    key={c}
                    onClick={() => { setCurrency(c); setCurrencyOpen(false); }}
                    className={`w-full text-center px-2 py-1.5 text-[11px] font-medium transition-colors ${
                      c === currency ? "text-electric bg-electric/5" : "text-foreground hover:bg-muted/40"
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <h1 className="text-4xl font-display font-bold text-foreground tracking-tight">
            {currencySymbol}{totalValue > 0 ? totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "—"}
          </h1>
          {hasWallet && walletAddress && (
            <div className="text-[11px] text-muted-foreground/40 mt-1 flex items-center justify-center gap-1.5">
              <CopyAddress address={walletAddress} />
              <span>·</span>
              <span>{chainName}</span>
            </div>
          )}
          {hasWallet && (
            <p className="text-[11px] text-muted-foreground/40 mt-0.5 flex items-center justify-center gap-1">
              Live balances on X Layer
              <button onClick={fetchBalances} disabled={isFetchingBalances} className="hover:text-electric transition-colors">
                <RefreshCw className={`w-3 h-3 ${isFetchingBalances ? 'animate-spin' : ''}`} />
              </button>
            </p>
          )}
          {!hasWallet && (
            <p className="text-xs text-muted-foreground/50 mt-1">Connect wallet to view your assets</p>
          )}
        </div>

        {/* ═══ ASSET CHANGE GRAPH ═══ */}
        <div className="rounded-2xl border border-border/50 bg-gradient-to-b from-white to-muted/10 p-5 mb-5">
          {/* Time span selector */}
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-medium text-muted-foreground">Asset Change</span>
            <div className="flex gap-1 bg-muted/30 rounded-lg p-0.5">
              {(["1D", "1W", "1M"] as TimeSpan[]).map(ts => (
                <button
                  key={ts}
                  onClick={() => setTimeSpan(ts)}
                  className={`px-3 py-1 text-[11px] font-semibold rounded-md transition-all ${
                    ts === timeSpan
                      ? "bg-white text-foreground shadow-sm"
                      : "text-muted-foreground/60 hover:text-muted-foreground"
                  }`}
                >
                  {ts}
                </button>
              ))}
            </div>
          </div>

          {/* Chart Graphic */}
          {hasWallet ? (
            <div className="h-32 flex items-center justify-center relative">
              <svg className="w-full h-full drop-shadow-md" viewBox="0 0 400 120" preserveAspectRatio="none">
                <defs>
                  <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="oklch(0.62 0.19 260)" stopOpacity="0.3" />
                    <stop offset="100%" stopColor="oklch(0.62 0.19 260)" stopOpacity="0" />
                  </linearGradient>
                  <linearGradient id="lineGrad" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="oklch(0.62 0.19 260)" />
                    <stop offset="100%" stopColor="oklch(0.7 0.19 260)" />
                  </linearGradient>
                </defs>
                
                {/* Area under the curve */}
                <path 
                  d="M0,120 L0,80 C50,60 100,90 150,70 C200,50 250,60 300,30 C350,0 380,20 400,10 L400,120 Z" 
                  fill="url(#chartGrad)" 
                  className="animate-pulse"
                  style={{ animationDuration: '3s' }}
                />
                
                {/* The glowing curve */}
                <path 
                  d="M0,80 C50,60 100,90 150,70 C200,50 250,60 300,30 C350,0 380,20 400,10" 
                  stroke="url(#lineGrad)" 
                  strokeWidth="3" 
                  strokeLinecap="round" 
                  fill="none"
                  style={{ filter: "drop-shadow(0px 4px 6px oklch(0.62 0.19 260 / 0.4))" }}
                />
                
                {/* Dots along the curve */}
                <circle cx="150" cy="70" r="4" fill="white" stroke="oklch(0.62 0.19 260)" strokeWidth="2" />
                <circle cx="300" cy="30" r="4" fill="white" stroke="oklch(0.62 0.19 260)" strokeWidth="2" />
                <circle cx="400" cy="10" r="4" fill="white" stroke="oklch(0.62 0.19 260)" strokeWidth="2" className="animate-ping" />
              </svg>

              {/* Fake overlay info */}
              <div className="absolute top-2 right-2 flex flex-col items-end">
                <span className="text-[10px] text-muted-foreground font-semibold uppercase tracking-widest">Growth</span>
                <span className="text-sm font-bold text-emerald-500">+12.4%</span>
              </div>
            </div>
          ) : (
            <div className="h-28 flex items-center justify-center">
              <p className="text-xs text-muted-foreground/40">Connect wallet to view asset history</p>
            </div>
          )}
        </div>

        {/* ═══ QUICK ACTIONS ═══ */}
        <div className="flex justify-center gap-8 mb-7">
          <button
            onClick={() => { setShowHistory(true); setShowAddCoin(false); }}
            className="flex flex-col items-center gap-1.5 group"
          >
            <div className="w-12 h-12 rounded-full bg-gradient-brand flex items-center justify-center shadow-soft group-hover:shadow-glow transition-shadow">
              <Clock className="w-5 h-5 text-white" />
            </div>
            <span className="text-[11px] font-medium text-muted-foreground group-hover:text-foreground transition-colors">History</span>
          </button>
          <button
            onClick={() => { setShowAddCoin(true); setShowHistory(false); }}
            className="flex flex-col items-center gap-1.5 group"
          >
            <div className="w-12 h-12 rounded-full bg-gradient-brand flex items-center justify-center shadow-soft group-hover:shadow-glow transition-shadow">
              <Plus className="w-5 h-5 text-white" />
            </div>
            <span className="text-[11px] font-medium text-muted-foreground group-hover:text-foreground transition-colors">Add Coin</span>
          </button>
        </div>

        {/* ═══ HISTORY PANEL ═══ */}
        <div
          className="overflow-hidden mb-5"
          style={{
            maxHeight: showHistory ? "400px" : "0px",
            opacity: showHistory ? 1 : 0,
            transition: "max-height 0.25s ease-out, opacity 0.2s ease-out",
          }}
        >
          <div className="rounded-2xl border border-border/50 bg-white p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Clock className="w-4 h-4 text-electric" />
                Transaction History
              </h3>
              <button onClick={() => setShowHistory(false)} className="p-1 rounded-lg hover:bg-muted/40 transition-colors">
                <X className="w-3.5 h-3.5 text-muted-foreground" />
              </button>
            </div>
            {txRecords.length === 0 ? (
              <div className="text-center py-6">
                <Clock className="w-8 h-8 text-muted-foreground/15 mx-auto mb-2" />
                <p className="text-sm text-muted-foreground/60">No trade activity yet.</p>
                <p className="text-[11px] text-muted-foreground/30 mt-0.5">Executed trades will appear here.</p>
              </div>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
                {txRecords.map((tx) => (
                  <div key={tx.id} className="flex items-center justify-between bg-muted/30 rounded-xl px-3 py-2.5 gap-2">
                    <div className="flex flex-col gap-0.5 min-w-0">
                      <span className="text-xs font-bold text-foreground truncate">
                        {tx.fromSymbol} → {tx.toSymbol}
                      </span>
                      <span className="text-[10px] text-muted-foreground">
                        {new Date(tx.confirmedAt).toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                      </span>
                    </div>
                    <div className="flex flex-col items-end gap-0.5 shrink-0">
                      <span className="text-xs font-bold text-emerald-600">+${tx.expectedOutputUsd.toFixed(2)}</span>
                      <span className="text-[10px] text-muted-foreground">gas ${tx.gasFeeUsd.toFixed(4)}</span>
                    </div>
                    {tx.explorerUrl && (
                      <a href={tx.explorerUrl} target="_blank" rel="noopener noreferrer" className="ml-1 text-electric hover:opacity-70 transition-opacity">
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* ═══ ADD COIN PANEL ═══ */}
        <div
          className="overflow-hidden mb-5"
          style={{
            maxHeight: showAddCoin ? "400px" : "0px",
            opacity: showAddCoin ? 1 : 0,
            transition: "max-height 0.25s ease-out, opacity 0.2s ease-out",
          }}
        >
          <div className="rounded-2xl border border-border/50 bg-white p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Plus className="w-4 h-4 text-electric" />
                Add Coin
              </h3>
              <button onClick={() => setShowAddCoin(false)} className="p-1 rounded-lg hover:bg-muted/40 transition-colors">
                <X className="w-3.5 h-3.5 text-muted-foreground" />
              </button>
            </div>
            <p className="text-[11px] text-muted-foreground/60 mb-3">
              Add a token by coin ID or contract address. This is saved locally only.
            </p>
            <div className="flex gap-2">
              <input
                type="text"
                value={addCoinInput}
                onChange={e => setAddCoinInput(e.target.value)}
                placeholder="Token symbol or 0x… address"
                className="flex-1 bg-muted/20 border border-border/50 rounded-xl px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground/30 outline-none focus:border-electric/40 focus:bg-white transition-colors"
              />
              <button
                onClick={() => {
                  if (addCoinInput.trim()) {
                    setAddedCoins(prev => [...prev, addCoinInput.trim()]);
                    setAddCoinInput("");
                  }
                }}
                disabled={!addCoinInput.trim()}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                  addCoinInput.trim()
                    ? "bg-gradient-brand text-white hover:shadow-glow"
                    : "bg-muted/40 text-muted-foreground/30 cursor-not-allowed"
                }`}
              >
                Add
              </button>
            </div>
            {addedCoins.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1.5">
                {addedCoins.map((coin, i) => (
                  <span key={i} className="inline-flex items-center gap-1 bg-muted/30 border border-border/40 rounded-lg px-2.5 py-1 text-[11px] font-medium text-foreground">
                    {coin.length > 10 ? `${coin.slice(0, 6)}…${coin.slice(-4)}` : coin}
                    <button onClick={() => setAddedCoins(prev => prev.filter((_, j) => j !== i))} className="text-muted-foreground/40 hover:text-red-500 transition-colors">
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* ═══ CRYPTO ASSETS ═══ */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
                <Coins className="w-4 h-4 text-electric" />
                Popular Tokens
              </h2>
              <p className="text-[10px] text-muted-foreground/40 ml-6">on {chainName} · not wallet holdings</p>
            </div>
          </div>

          {/* Search */}
          <div className="relative mb-3">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground/30" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search tokens…"
              className="w-full bg-muted/15 border border-border/40 rounded-xl pl-9 pr-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/30 outline-none focus:border-electric/40 focus:bg-white transition-colors"
            />
          </div>

          {/* Asset list */}
          {!hasWallet ? (
            <div className="rounded-2xl border border-border/50 bg-white p-6 text-center">
              <Wallet className="w-8 h-8 text-muted-foreground/15 mx-auto mb-2" />
              <p className="text-sm text-muted-foreground/60 mb-3">Connect wallet to view your assets.</p>
              <button onClick={onConnectWallet} className="inline-flex items-center gap-2 rounded-full border border-electric/30 text-electric px-4 py-1.5 text-sm font-medium hover:bg-electric/5 transition-colors">
                <Wallet className="w-3.5 h-3.5" />
                Connect Wallet
              </button>
            </div>
          ) : (
            <div className="rounded-2xl border border-border/50 bg-white overflow-hidden">
              {filteredAssets.length > 0 ? (
                <div className="divide-y divide-border/30">
                  {filteredAssets.map(asset => (
                    <div key={asset.symbol} className="flex items-center gap-3 px-4 py-3.5 hover:bg-muted/20 transition-colors">
                      {/* Token icon */}
                      <div
                        className="w-9 h-9 rounded-full flex items-center justify-center text-white text-[11px] font-bold shrink-0"
                        style={{ backgroundColor: asset.color }}
                      >
                        {asset.symbol.slice(0, 2)}
                      </div>
                      {/* Token info */}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-foreground">{asset.symbol}</p>
                        <p className="text-[11px] text-muted-foreground/50 truncate">{asset.name}</p>
                      </div>
                      {/* Balance */}
                      <div className="text-right">
                        <p className="text-sm font-medium text-foreground">
                          {balances[asset.symbol] !== undefined ? `${balances[asset.symbol]} ${asset.symbol}` : "—"}
                        </p>
                        <p className="text-[11px] text-muted-foreground/50">
                          {balances[asset.symbol] && prices[asset.symbol]?.[currencyKey]
                            ? `${currencySymbol}${(parseFloat(balances[asset.symbol]) * prices[asset.symbol][currencyKey]).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                            : "—"}
                        </p>
                      </div>
                    </div>
                  ))}
                  {/* Added coins */}
                  {addedCoins.map((coin, i) => (
                    <div key={`added-${i}`} className="flex items-center gap-3 px-4 py-3.5 hover:bg-muted/20 transition-colors">
                      <div className="w-9 h-9 rounded-full bg-muted/40 flex items-center justify-center text-muted-foreground text-[11px] font-bold shrink-0">
                        ?
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-foreground">{coin.length > 10 ? `${coin.slice(0, 6)}…${coin.slice(-4)}` : coin}</p>
                        <p className="text-[11px] text-muted-foreground/50">Custom token</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-foreground/20">—</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Search className="w-6 h-6 text-muted-foreground/15 mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground/40">No tokens match &ldquo;{searchQuery}&rdquo;</p>
                </div>
              )}
            </div>
          )}

          {/* Add coin helper */}
          <button
            onClick={() => { setShowAddCoin(true); }}
            className="mt-3 w-full flex items-center justify-center gap-1.5 text-[12px] font-medium text-electric/70 hover:text-electric transition-colors py-2"
          >
            <Plus className="w-3.5 h-3.5" />
            Add coin ID you don&apos;t see here
          </button>
        </div>
      </div>
    </div>
  );
}
