"use client";

import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowRight,
  Eye,
  AlertTriangle,
  ShieldCheck,
  Loader2,
  CheckCircle2,
  XCircle,
  ExternalLink,
  Lock,
} from "lucide-react";
import { useState, useCallback, useEffect, useRef } from "react";
import type { SimulationResult } from "../lib/schemas";
import { addTx } from "../lib/tx-store";

type ExecutionState =
  | "idle"
  | "approving"
  | "confirming"
  | "building_tx"
  | "awaiting_signature"
  | "submitted"
  | "confirmed"
  | "failed"
  | "rejected"
  | "wrong_chain"
  | "expired";

interface Props {
  quote: SimulationResult;
  fromSymbol: string;
  toSymbol?: string;
  approvalId?: string;
  showExecute?: boolean;
  getAccessToken?: () => Promise<string | null>;
  getIdentityToken?: () => Promise<string | null>;
  walletAddress?: string | null;
  targetWalletAddress?: string | null;
  onConnectWallet?: () => void;
  amount?: number;
  tokenAddress?: string;
  scanDecision?: string;
  chainConfig?: import("../lib/chains").ChainConfig;
  needsApproval?: boolean;
  approveTxData?: { to: string; data: string; value: string; chainId?: string; gas?: string; gasLimit?: string; gasPrice?: string; maxFeePerGas?: string; maxPriorityFeePerGas?: string; } | null;
  onConfirmed?: () => void;
}

interface EthereumProvider {
  request: (args: { method: string; params?: unknown[] }) => Promise<unknown>;
}

function getEthereumProvider(): EthereumProvider | null {
  if (typeof window === "undefined") return null;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const w = window as any;
  return w.ethereum ?? null;
}

const WALLET_ERROR_CODES: Record<number, ExecutionState> = {
  4001: "rejected",
  4100: "rejected",
  4902: "wrong_chain",
};

export function QuoteCard({
  quote,
  fromSymbol,
  toSymbol,
  approvalId,
  showExecute = false,
  getAccessToken,
  getIdentityToken,
  walletAddress,
  targetWalletAddress,
  onConnectWallet,
  amount,
  tokenAddress,
  scanDecision,
  chainConfig,
  needsApproval,
  approveTxData,
  onConfirmed,
}: Props) {
  const slippageOk = quote.slippage < 3;
  const [execState, setExecState] = useState<ExecutionState>("idle");
  const [txHash, setTxHash] = useState<string | null>(null);
  const [approvalTxHash, setApprovalTxHash] = useState<string | null>(null);
  const [explorerUrl, setExplorerUrl] = useState<string | null>(null);
  const [execError, setExecError] = useState<string | null>(null);
  const [showErrorDetail, setShowErrorDetail] = useState(false);
  const [riskAcknowledged, setRiskAcknowledged] = useState(false);
  const [currentNeedsApproval, setCurrentNeedsApproval] = useState(!!needsApproval);

  // Expiry + countdown timer (2 minutes)
  const EXPIRY_MS = 2 * 60 * 1000;
  const [isExpired, setIsExpired] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(Math.floor(EXPIRY_MS / 1000));
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const startTime = Date.now();
    const expireTimer = setTimeout(() => {
      setIsExpired(true);
      setExecState("expired");
      if (countdownRef.current) clearInterval(countdownRef.current);
    }, EXPIRY_MS);

    countdownRef.current = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const remaining = Math.max(0, Math.floor((EXPIRY_MS - elapsed) / 1000));
      setSecondsLeft(remaining);
    }, 1000);

    return () => {
      clearTimeout(expireTimer);
      if (countdownRef.current) clearInterval(countdownRef.current);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const walletMismatch = targetWalletAddress && walletAddress && targetWalletAddress.toLowerCase() !== walletAddress.toLowerCase();
  const isHighRisk = scanDecision && scanDecision !== "safe";
  const liveMode = process.env.NEXT_PUBLIC_ENABLE_LIVE_EXECUTION === "true";

  // Switch wallet to X Layer before any signing attempt.
  // Tries wallet_switchEthereumChain first; if chain is unknown (4902),
  // adds it via wallet_addEthereumChain then retries.
  const ensureXLayer = async (provider: { request: (args: { method: string; params?: unknown[] }) => Promise<unknown> }): Promise<void> => {
    const X_LAYER_CHAIN_ID = "0xc4"; // 196 in hex
    try {
      await provider.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: X_LAYER_CHAIN_ID }],
      });
    } catch (switchErr: unknown) {
      const code = (switchErr as { code?: number })?.code;
      if (code === 4902) {
        await provider.request({
          method: "wallet_addEthereumChain",
          params: [{
            chainId: X_LAYER_CHAIN_ID,
            chainName: "X Layer Mainnet",
            nativeCurrency: { name: "OKB", symbol: "OKB", decimals: 18 },
            rpcUrls: ["https://rpc.xlayer.tech"],
            blockExplorerUrls: ["https://www.oklink.com/xlayer"],
          }],
        });
        await provider.request({
          method: "wallet_switchEthereumChain",
          params: [{ chainId: X_LAYER_CHAIN_ID }],
        });
      } else {
        throw switchErr;
      }
    }
  };

  const handleExecute = useCallback(async () => {
    if (!approvalId || !walletAddress || isExpired || isHighRisk || walletMismatch) return;
    
    if (currentNeedsApproval && approveTxData) {
      setExecState("approving");
      setExecError(null);
      const provider = getEthereumProvider();
      if (!provider) {
        setExecState("failed");
        setExecError("No wallet provider found.");
        return;
      }
      try {
        await ensureXLayer(provider);
        const txParams: Record<string, string> = { from: walletAddress, to: approveTxData.to, data: approveTxData.data };
        if (approveTxData.value) txParams.value = approveTxData.value;
        const hash = await provider.request({ method: "eth_sendTransaction", params: [txParams] }) as string;
        setApprovalTxHash(hash);
        setCurrentNeedsApproval(false);
        setExecState("idle");
        return;
      } catch (err: unknown) {
        setExecState("failed");
        setExecError((err as { message?: string })?.message || "User rejected approval.");
        return;
      }
    }

    setExecState("confirming");
    setExecError(null);

    try {
      let authToken = "client-token";
      let identityToken: string | null = null;
      if (getAccessToken) { try { const t = await getAccessToken(); if (t) authToken = t; } catch { /* */ } }
      if (getIdentityToken) { try { identityToken = await getIdentityToken(); } catch { /* */ } }

      setExecState("building_tx");
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${authToken}`,
        "x-wallet-address": walletAddress,
      };
      if (identityToken) headers["x-privy-identity-token"] = identityToken;

      const execRes = await fetch("/api/execute", {
        method: "POST",
        headers,
        body: JSON.stringify({
          approvalId,
          riskAcknowledged,
          approvalTxHash,
        }),
      });

      const execData = await execRes.json() as {
        executionId?: string;
        unsignedTx?: { to: string; data: string; value: string; chainId?: string; gas?: string; gasLimit?: string; gasPrice?: string; maxFeePerGas?: string; maxPriorityFeePerGas?: string; };
        error?: string; message?: string; result?: { status: string };
      };

      if (execData.result?.status === "execution_disabled") {
        setExecState("idle");
        setExecError(execData.message ?? "Live execution is disabled.");
        return;
      }

      if (!execRes.ok || !execData.unsignedTx) {
        setExecState("failed");
        setExecError(execData.error ?? "Failed to build transaction.");
        return;
      }

      setExecState("awaiting_signature");
      const provider = getEthereumProvider();
      if (!provider) {
        setExecState("failed");
        setExecError("No wallet provider found. Please install MetaMask or use Privy embedded wallet.");
        return;
      }

      try {
        await ensureXLayer(provider);
      } catch {
        setExecState("failed");
        setExecError("Please switch your wallet to X Layer to continue.");
        return;
      }

      const tx = execData.unsignedTx;
      const txParams: Record<string, string> = { from: walletAddress, to: tx.to, data: tx.data, value: tx.value };

      let hash: string;
      try {
        hash = (await provider.request({ method: "eth_sendTransaction", params: [txParams] })) as string;
      } catch (walletError: unknown) {
        const code = (walletError as { code?: number })?.code;
        if (code && WALLET_ERROR_CODES[code]) {
          setExecState(WALLET_ERROR_CODES[code]);
          setExecError(code === 4001 ? "Transaction rejected by wallet." : code === 4902 ? "Please switch to the correct chain." : "Wallet authorization failed.");
        } else {
          setExecState("failed");
          setExecError(`Wallet error: ${walletError instanceof Error ? walletError.message : String(walletError)}`);
        }
        return;
      }

      setTxHash(hash);
      setExecState("submitted");

      try {
        const confirmRes = await fetch("/api/confirm", { method: "POST", headers, body: JSON.stringify({ executionId: execData.executionId, txHash: hash, chainId: tx.chainId }) });
        const confirmData = await confirmRes.json() as { status?: string; explorerUrl?: string };
        if (confirmData.explorerUrl) setExplorerUrl(confirmData.explorerUrl);
        if (confirmData.status === "confirmed") {
          setExecState("confirmed");
          const confirmedAt = new Date().toISOString();
          const txRecord = {
            id: hash,
            fromSymbol: fromSymbol ?? "?",
            toSymbol: toSymbol ?? "?",
            amountUsd: amount ?? 0,
            expectedOutputUsd: quote.expectedOutputUsd,
            gasFeeUsd: quote.gasFeeUsd,
            txHash: hash,
            explorerUrl: confirmData.explorerUrl ?? null,
            chain: chainConfig?.name ?? "X Layer",
            confirmedAt,
          };
          addTx(txRecord);
          // Persist to DB — fire and forget, non-blocking
          fetch("/api/tx-history", {
            method: "POST",
            headers,
            body: JSON.stringify(txRecord),
          }).catch(() => {/* non-fatal */});
          onConfirmed?.();
        }
        else if (confirmData.status === "reverted" || confirmData.status === "failed") { setExecState("failed"); setExecError("Transaction reverted on-chain."); }
      } catch { /* tx submitted, user checks explorer */ }
    } catch (err) {
      setExecState("failed");
      setExecError(`Execution error: ${err instanceof Error ? err.message : String(err)}`);
    }
  }, [approvalId, walletAddress, getAccessToken, getIdentityToken, quote, riskAcknowledged, isExpired, isHighRisk, walletMismatch, currentNeedsApproval, approveTxData, approvalTxHash]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white border border-border rounded-2xl overflow-hidden shadow-soft"
    >
      {/* ── SUCCESS STATE: replace entire card ── */}
      {execState === "confirmed" && (
        <div className="p-4 space-y-3">
          <div className="flex items-center gap-2 text-emerald-600">
            <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
            <span className="text-sm font-bold">Transaction confirmed</span>
          </div>
          <div className="bg-emerald-50 border border-emerald-100 rounded-xl px-3 py-2.5 text-xs text-emerald-700 space-y-0.5">
            <p><span className="font-semibold">{fromSymbol} → {toSymbol ?? "Target"}</span></p>
            <p>Output: ~${quote.expectedOutputUsd.toFixed(2)}</p>
            <p className="font-mono text-[10px] text-emerald-500 break-all">{txHash}</p>
          </div>
          <div className="flex gap-2">
            {explorerUrl && (
              <a
                href={explorerUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-2 px-3 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg text-[11px] font-bold flex items-center justify-center gap-2 transition-colors"
              >
                Explorer <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>
          <p className="text-[10px] text-muted-foreground/50 text-center">Check History in Portfolio for details.</p>
        </div>
      )}

      {/* ── NORMAL CARD STATE ── */}
      {execState !== "confirmed" && (
        <>
      {/* Header with countdown */}
      <div className="px-4 py-3 border-b border-border bg-muted/20 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Eye className="w-4 h-4 text-electric" />
          <h4 className="text-xs font-bold uppercase tracking-widest text-foreground">Trade Preview</h4>
        </div>
        {/* Countdown timer */}
        {!isExpired && execState === "idle" && (
          <div
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold tabular-nums"
            style={{
              background: secondsLeft < 30 ? "oklch(0.98 0.01 27)" : "oklch(0.975 0.005 250)",
              color: secondsLeft < 30 ? "oklch(0.55 0.22 27)" : "oklch(0.55 0.02 260)",
              border: `1px solid ${secondsLeft < 30 ? "oklch(0.88 0.08 27)" : "oklch(0.92 0.01 260)"}`,
            }}
          >
            <span className={`w-1.5 h-1.5 rounded-full inline-block ${secondsLeft < 30 ? "bg-red-400 animate-pulse" : "bg-muted-foreground/40"}`} />
            {Math.floor(secondsLeft / 60)}:{String(secondsLeft % 60).padStart(2, "0")}
          </div>
        )}
        {isExpired && (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-red-50 text-red-500 border border-red-100">
            <XCircle className="w-3 h-3" /> Expired
          </span>
        )}
      </div>

      <div className="p-4 space-y-3">
        {/* Route */}
        <div className="flex items-center gap-3">
          <span className="font-bold text-foreground text-sm">{fromSymbol}</span>
          <ArrowRight className="w-4 h-4 text-muted-foreground" />
          <span className="font-bold text-foreground text-sm">{toSymbol ?? "Target"}</span>
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-muted/40 rounded-xl px-3 py-2.5">
            <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-0.5">Expected Output</p>
            <p className="text-sm font-bold text-foreground">${quote.expectedOutputUsd.toFixed(2)}</p>
          </div>
          <div className="bg-muted/40 rounded-xl px-3 py-2.5">
            <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-0.5">Slippage</p>
            <p className={`text-sm font-bold ${slippageOk ? "text-emerald-600" : "text-red-600"}`}>{quote.slippage.toFixed(2)}%</p>
          </div>
          <div className="bg-muted/40 rounded-xl px-3 py-2.5">
            <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-0.5">Gas Fee</p>
            <p className="text-sm font-bold text-foreground">${quote.gasFeeUsd.toFixed(4)}</p>
          </div>
        </div>

        {/* Route info */}
        <div className="text-[10px] text-muted-foreground bg-muted/40 rounded-lg px-3 py-2 font-mono break-all">
          <p>Amount: {amount ? `$${amount}` : "Unknown"} {fromSymbol}</p>
          <p>Token: {tokenAddress || "Unknown"}</p>
          <p>Router: {quote.route}</p>
        </div>

        {/* Chain & Security info */}
        <div className="space-y-1.5 text-xs">
          {chainConfig ? (
            <div className="flex items-center gap-2 bg-muted/20 border border-border/50 rounded-lg px-3 py-2 text-muted-foreground">
              <span className="font-semibold">{chainConfig.name}</span>
              <span>(ID: {chainConfig.id})</span>
            </div>
          ) : null}

          {scanDecision === "safe" ? (
            <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-100 rounded-lg px-3 py-2 text-emerald-700">
              <ShieldCheck className="w-3.5 h-3.5 flex-shrink-0" />
              LOW risk by current scan
            </div>
          ) : scanDecision ? (
            <div className="flex items-center gap-2 bg-red-50 border border-red-200 rounded-lg px-3 py-2 text-red-700 font-semibold">
              <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
              BLOCKED: {scanDecision === "high_risk" ? "MEDIUM/HIGH risk detected" : "Unknown risk state"}
            </div>
          ) : null}

          {walletAddress && targetWalletAddress && (
            <div className={`flex items-center gap-2 border rounded-lg px-3 py-2 ${walletMismatch ? "bg-red-50 border-red-200 text-red-700 font-semibold" : "bg-muted/20 border-border/50 text-muted-foreground"}`}>
              <Lock className="w-3.5 h-3.5 flex-shrink-0" />
              <span>Verified Wallet: {targetWalletAddress.slice(0,6)}...{targetWalletAddress.slice(-4)}</span>
              {walletMismatch && <span className="ml-auto">Mismatch! Connect correct wallet.</span>}
            </div>
          )}
        </div>

        {/* Slippage warning */}
        {!slippageOk && (
          <div className="flex items-center gap-2 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
            <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
            High slippage detected. Review carefully before confirming.
          </div>
        )}

        {isExpired && (
          <div className="flex items-center gap-2 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
            <XCircle className="w-3.5 h-3.5 flex-shrink-0" />
            Quote expired, request a new quote.
          </div>
        )}

      {/* ── Execution Section ── */}
        <AnimatePresence mode="wait">
          {showExecute && approvalId && execState === "idle" && (
            <motion.div key="confirm-button" initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }} className="space-y-3 pt-3 border-t border-border/50">
              {walletAddress ? (
                <>
                  <div className="flex items-start gap-2 text-xs text-muted-foreground bg-blue-50 border border-blue-100 rounded-lg px-3 py-2.5">
                    <ShieldCheck className="w-3.5 h-3.5 flex-shrink-0 text-blue-500 mt-0.5" />
                    <div>
                      <p className="font-semibold text-blue-800 mb-0.5">User-Signed Execution (Trade Hard Cap Applies)</p>
                      <p>Your wallet will ask you to review and sign. PhylaX never signs for you.</p>
                    </div>
                  </div>
                  
                  {liveMode ? (
                    <label className="flex items-start gap-2 text-[11px] text-muted-foreground cursor-pointer bg-muted/20 p-2 rounded-lg border border-border/50 hover:bg-muted/40 transition-colors">
                      <input 
                        type="checkbox" 
                        className="mt-0.5 rounded border-gray-300 text-electric focus:ring-electric"
                        checked={riskAcknowledged}
                        onChange={(e) => setRiskAcknowledged(e.target.checked)}
                      />
                      <span>
                        I acknowledge the risks of on-chain trading and accept that PhylaX is not responsible for any losses.
                      </span>
                    </label>
                  ) : null}

                  <div className="flex flex-col gap-2">
                    <button
                      id="confirm-execute-btn"
                      onClick={handleExecute}
                      disabled={(liveMode && !riskAcknowledged) || isExpired || isHighRisk || !!walletMismatch || execState !== "idle"}
                      className={`w-full py-3 px-4 rounded-xl text-sm font-bold transition-all duration-200 flex items-center justify-center gap-2 ${
                        (!liveMode || riskAcknowledged) && !isExpired && !isHighRisk && !walletMismatch && execState === "idle"
                          ? "bg-gradient-brand text-white hover:shadow-glow hover:scale-[1.01]" 
                          : "bg-muted text-muted-foreground cursor-not-allowed"
                      }`}
                    >
                      <ShieldCheck className="w-4 h-4" />
                      {currentNeedsApproval ? "Approve USDC spending" : "Sign swap in wallet"}
                    </button>
                    
                    {walletMismatch && (
                      <button
                        onClick={onConnectWallet}
                        className="w-full py-2 px-4 rounded-xl border border-red-200 text-red-600 text-[11px] font-bold hover:bg-red-50 transition-all flex items-center justify-center gap-2"
                      >
                        Switch to {targetWalletAddress?.slice(0,6)}...
                      </button>
                    )}
                  </div>
                </>
              ) : (
                <>
                  <div className="flex items-start gap-2 text-xs text-amber-700 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2.5">
                    <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                    <p>Wallet connection required to sign and submit this transaction.</p>
                  </div>
                  <button
                    onClick={onConnectWallet}
                    className="w-full py-3 px-4 rounded-xl border border-electric/30 text-electric text-sm font-bold hover:bg-electric/5 transition-all duration-200 flex items-center justify-center gap-2"
                  >
                    Connect Wallet to Sign
                  </button>
                </>
              )}
            </motion.div>
          )}

          {!showExecute && execState === "idle" && (
            <motion.div key="exec-disabled" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="pt-3 border-t border-border/50">
              <div className="flex items-center gap-2 text-xs text-muted-foreground bg-muted/40 border border-border rounded-lg px-3 py-2.5">
                <Lock className="w-3.5 h-3.5 flex-shrink-0" />
                Live execution disabled on {chainConfig?.name || "this chain"}
              </div>
            </motion.div>
          )}

          {(execState === "confirming" || execState === "building_tx" || execState === "approving") && (
            <motion.div key="building" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center gap-2 text-sm text-electric font-medium pt-3 border-t border-border/50">
              <Loader2 className="w-4 h-4 animate-spin" />
              {execState === "approving" ? "Awaiting approval signature…" : execState === "confirming" ? "Preparing transaction…" : "Building transaction data…"}
            </motion.div>
          )}

          {execState === "awaiting_signature" && (
            <motion.div key="signing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col gap-3 pt-3 border-t border-border/50">
              {/* Prominent signature prompt */}
              <div
                className="flex items-center gap-3 px-4 py-3.5 rounded-xl border"
                style={{
                  background: "oklch(0.98 0.02 85 / 0.5)",
                  borderColor: "oklch(0.88 0.08 85)",
                  animation: "pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
                }}
              >
                <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: "oklch(0.65 0.18 85 / 0.15)" }}>
                  <Loader2 className="w-5 h-5 animate-spin" style={{ color: "oklch(0.55 0.18 85)" }} />
                </div>
                <div>
                  <p className="text-sm font-bold" style={{ color: "oklch(0.45 0.18 85)" }}>
                    Check your wallet
                  </p>
                  <p className="text-[11px]" style={{ color: "oklch(0.55 0.12 85)" }}>
                    Signature required to proceed
                  </p>
                </div>
              </div>
              <button
                onClick={() => setExecState("idle")}
                className="text-[11px] text-muted-foreground hover:text-foreground underline underline-offset-2 w-fit"
              >
                Cancel and return
              </button>
            </motion.div>
          )}

          {execState === "submitted" && (
            <motion.div key="submitted" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-3 pt-3 border-t border-border/50">
              <div className="flex items-center gap-2 text-sm text-blue-600 font-medium">
                <Loader2 className="w-4 h-4 animate-spin" />
                Transaction submitted…
              </div>
              <div className="flex flex-wrap gap-2">
                {explorerUrl && (
                  <a href={explorerUrl} target="_blank" rel="noopener noreferrer" className="flex-1 py-2 px-3 bg-muted hover:bg-muted/60 rounded-lg text-[11px] font-bold text-foreground flex items-center justify-center gap-2 transition-colors">
                    View on Explorer <ExternalLink className="w-3 h-3" />
                  </a>
                )}
                <button 
                  onClick={() => setExecState("idle")}
                  className="flex-1 py-2 px-3 border border-border rounded-lg text-[11px] font-bold text-muted-foreground hover:bg-muted/20 flex items-center justify-center transition-colors"
                >
                  Check status
                </button>
              </div>
            </motion.div>
          )}

          {(execState === "failed" || execState === "rejected" || execState === "wrong_chain" || execState === "expired") && (
            <motion.div key="error" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-3 pt-3 border-t border-border/50">
              <div className="flex items-center gap-2 text-sm text-red-600 font-medium">
                <XCircle className="w-4 h-4" />
                {execState === "rejected" ? "Rejected by wallet" : execState === "wrong_chain" ? "Switch to X Layer" : execState === "expired" ? "Quote expired" : "Execution failed"}
              </div>
              
              <div className="flex flex-col gap-2">
                <button 
                  onClick={() => {
                    setExecState("idle");
                    setIsExpired(false);
                    // Re-triggering a re-quote is planned for the next UI iteration
                  }}
                  className="w-full py-2.5 px-4 bg-electric text-white rounded-xl text-xs font-bold hover:shadow-glow transition-all flex items-center justify-center gap-2"
                >
                  Refresh quote
                </button>
                
                <div className="flex gap-2">
                  <button 
                    type="button"
                    onClick={() => setExecState("idle")}
                    className="flex-1 py-2 px-3 border border-border rounded-lg text-[11px] font-bold text-muted-foreground hover:bg-muted/20 flex items-center justify-center"
                  >
                    Scan another token
                  </button>
                  <button 
                    onClick={() => setExecState("idle")}
                    className="flex-1 py-2 px-3 border border-border rounded-lg text-[11px] font-bold text-muted-foreground hover:bg-muted/20 flex items-center justify-center"
                  >
                    Change amount
                  </button>
                </div>
              </div>

              {execError && (
                <div className="mt-2">
                  <button onClick={() => setShowErrorDetail((v) => !v)} className="text-[10px] text-muted-foreground hover:text-foreground transition-colors">
                    {showErrorDetail ? "▾ Hide error detail" : "▸ Show error detail"}
                  </button>
                  {showErrorDetail && <p className="text-xs text-red-500 mt-1 font-mono break-all bg-red-50 p-2 rounded border border-red-100">{execError}</p>}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      </>
      )}
    </motion.div>
  );
}
