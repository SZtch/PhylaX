"use client";

import { useEffect, useState } from "react";
import Image from "next/image";

const PARTICLES = [
  { top: "12%", left: "8%", size: 3, delay: 0 },
  { top: "18%", left: "72%", size: 2, delay: 0.4 },
  { top: "25%", left: "45%", size: 1.5, delay: 0.8 },
  { top: "30%", left: "15%", size: 2.5, delay: 1.1 },
  { top: "38%", left: "85%", size: 2, delay: 0.2 },
  { top: "45%", left: "60%", size: 1.5, delay: 0.6 },
  { top: "55%", left: "5%", size: 3, delay: 1.3 },
  { top: "62%", left: "90%", size: 2, delay: 0.3 },
  { top: "68%", left: "30%", size: 1.5, delay: 0.9 },
  { top: "72%", left: "55%", size: 2.5, delay: 0.5 },
  { top: "78%", left: "78%", size: 2, delay: 1.0 },
  { top: "82%", left: "18%", size: 1.5, delay: 0.7 },
  { top: "88%", left: "42%", size: 3, delay: 0.1 },
  { top: "92%", left: "65%", size: 2, delay: 1.2 },
  { top: "20%", left: "32%", size: 1.5, delay: 0.4 },
  { top: "50%", left: "25%", size: 2, delay: 0.8 },
];

const MESSAGES = [
  "BOOTING GUARD LAYER",
  "CONNECTING X LAYER",
  "LOADING OKX SKILLS",
  "INITIALIZING AGENT",
  "READY",
];

export function SplashScreen() {
  const [progress, setProgress] = useState(0);
  const [msgIdx, setMsgIdx] = useState(0);

  useEffect(() => {
    // Count from 0 → 100 over ~1.1s
    const start = performance.now();
    const duration = 1100;

    const tick = () => {
      const elapsed = performance.now() - start;
      const pct = Math.min(100, Math.round((elapsed / duration) * 100));
      setProgress(pct);
      if (pct < 100) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);

    // Cycle through messages
    const interval = setInterval(() => {
      setMsgIdx((i) => Math.min(i + 1, MESSAGES.length - 1));
    }, 240);

    return () => clearInterval(interval);
  }, []);

  return (
    <div
      className="fixed inset-0 flex flex-col items-center justify-center overflow-hidden"
      style={{
        background: "radial-gradient(ellipse 80% 60% at 50% 30%, oklch(0.22 0.06 265) 0%, oklch(0.13 0.03 265) 60%, oklch(0.10 0.02 265) 100%)",
      }}
    >
      {/* Particles */}
      {PARTICLES.map((p, i) => (
        <div
          key={i}
          className="absolute rounded-full"
          style={{
            top: p.top,
            left: p.left,
            width: p.size,
            height: p.size,
            background: `oklch(0.82 0.11 220 / 0.6)`,
            boxShadow: `0 0 ${p.size * 2}px oklch(0.82 0.11 220 / 0.4)`,
            animation: `pulse ${1.8 + p.delay}s ease-in-out infinite`,
            animationDelay: `${p.delay}s`,
          }}
        />
      ))}

      {/* Outer glow ring */}
      <div
        className="absolute"
        style={{
          width: 180,
          height: 180,
          borderRadius: "50%",
          background: "radial-gradient(circle, oklch(0.62 0.19 260 / 0.12) 0%, transparent 70%)",
          top: "calc(50% - 220px)",
          left: "50%",
          transform: "translateX(-50%)",
        }}
      />

      {/* Logo area */}
      <div className="relative flex flex-col items-center" style={{ marginBottom: 80 }}>
        {/* Shield icon — metallic layered */}
        <div className="relative" style={{ width: 96, height: 96 }}>
          {/* Outer glow */}
          <div
            className="absolute inset-0 rounded-full"
            style={{
              background: "radial-gradient(circle, oklch(0.62 0.19 260 / 0.25) 0%, transparent 70%)",
              transform: "scale(1.6)",
            }}
          />
            {/* PhylaX logo */}
          <div className="absolute inset-0 flex items-center justify-center">
            <Image
              src="/assets/PhylaX-mark.png"
              alt="PhylaX"
              width={96}
              height={96}
              className="object-contain"
              style={{ filter: "drop-shadow(0 0 20px oklch(0.62 0.19 260 / 0.7))" }}
              priority
            />
          </div>
        </div>
      </div>

      {/* Counter + bar */}
      <div className="flex flex-col items-center gap-4 w-full px-12 max-w-sm">
        {/* Percentage */}
        <div className="flex items-baseline gap-0.5">
          <span
            className="font-bold tabular-nums"
            style={{
              fontSize: 52,
              lineHeight: 1,
              color: "oklch(0.96 0.02 260)",
              letterSpacing: "-0.02em",
              textShadow: "0 0 30px oklch(0.62 0.19 260 / 0.6)",
            }}
          >
            {progress}
          </span>
          <span
            className="font-bold"
            style={{
              fontSize: 28,
              color: "oklch(0.96 0.02 260 / 0.7)",
            }}
          >
            %
          </span>
        </div>

        {/* Progress bar */}
        <div
          className="relative w-full rounded-full overflow-hidden"
          style={{
            height: 1.5,
            background: "oklch(1 0 0 / 0.1)",
          }}
        >
          <div
            className="absolute left-0 top-0 h-full rounded-full transition-all"
            style={{
              width: `${progress}%`,
              background: "linear-gradient(90deg, oklch(0.62 0.19 260), oklch(0.82 0.11 220))",
              boxShadow: "0 0 8px oklch(0.75 0.19 260)",
              transition: "width 0.05s linear",
            }}
          >
            {/* Glowing tip */}
            <div
              className="absolute right-0 top-1/2 -translate-y-1/2 rounded-full"
              style={{
                width: 5,
                height: 5,
                background: "white",
                boxShadow: "0 0 8px 2px oklch(0.82 0.11 220)",
              }}
            />
          </div>
        </div>

        {/* Status text */}
        <p
          className="text-center font-mono font-semibold tracking-[0.25em]"
          style={{
            fontSize: 10,
            color: "oklch(1 0 0 / 0.3)",
            letterSpacing: "0.25em",
          }}
        >
          {MESSAGES[msgIdx]}
        </p>
      </div>
    </div>
  );
}
