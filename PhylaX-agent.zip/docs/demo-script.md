# PhylaX Demo Script

## Setup
1. Clone the repo and run `npm install`.
2. Ensure `.env` is configured.
3. Run `npm run dev`.

## Script
**Presenter:** "Welcome to PhylaX, a risk-first KOL signal trading agent. Today we're going to use natural language to find and execute a safe trade based on smart money."

**Action:** Paste the following into the prompt:
> "Find a low-risk token on X Layer and quote $50 swap."

**Action:** Press **Enter**

**Presenter:** "PhylaX parses our intent into strict guardrails: a $50 max budget, conservative risk mode, and mandatory security scan."

**Presenter:** "It queries OKX for KOL signals, then automatically scans the contracts. Tokens flagged as Medium or High Risk are blocked automatically."

**Presenter:** "PhylaX retrieves a real-time quote from OKX DEX Aggregator. Notice the Trade Hard Cap notice and the requirement for a verified wallet signature."

**Action:** Click **Approve USDC spending** (if needed) then **Sign swap in wallet**.

**Presenter:** "The trade is signed by the user's wallet and submitted to X Layer. PhylaX proves that we can have an agentic DeFi experience without sacrificing security."
