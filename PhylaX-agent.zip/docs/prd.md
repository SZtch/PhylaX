# PhylaX PRD (Product Requirements Document)

## Overview
PhylaX is a natural-language DeFi agent that discovers KOL token signals, filters risky assets, simulates swaps, and executes approved trades through OKX. It is a risk-first, simulation-first, approval-gated trading agent.

## Positioning
- NOT a profit bot
- NOT a fully autonomous trading bot
- NOT a gambling UI
- IS an autonomous research and trade-preparation agent with approval-gated execution

## Core Workflows
1. **Thesis Input**: User provides natural language prompt
2. **Intent Parsing**: LLM translates intent to strict JSON parameters (budget, risk mode, etc)
3. **Signal Discovery**: Scans OKX DEX signals for tokens matching intent
4. **Security Scan**: Checks token risk levels via OKX security API
5. **Trade Plan**: Generates actionable table of safe tokens
6. **Simulation**: Simulates expected execution of selected token swap
7. **Approval**: Generates one-time `approvalId` and waits for user click
8. **Execution**: Executes trade using `approvalId` (live or simulated)
