# PhylaX Security & Guardrails

## Core Principles

1. **Simulation-First**: Every swap must be simulated before approval can be granted.
2. **Approval Gating**: Execution requires a valid, one-time-use, non-expired `approvalId` generated only after simulation passes.
3. **No Silent Fallback**: When `DATA_MODE=real`, any OKX API failure returns an explicit `502` error. Demo data is never substituted silently.

---

## Server-Side Guardrails (`/api/execute`)

The execution route enforces all of the following — Claude and the UI are never trusted for these:

| Guard | Behavior |
|---|---|
| Missing `approvalId` | Returns `400 Bad Request` |
| Expired `approvalId` (> 5 min) | Returns `403 Forbidden` |
| Already-used `approvalId` | Returns `403 Forbidden` |
| Amount exceeds budget | Returns `400 Bad Request` |
| High-risk token (blocked at simulation) | Cannot generate `approvalId` — blocked at `/api/simulate` |
| Unscanned token | Cannot generate `approvalId` — blocked at `/api/simulate` |
| Slippage over limit | Blocked at `/api/simulate` before `approvalId` is issued |
| `ENABLE_LIVE_EXECUTION=false` | Returns `simulated_execution` status even with valid `approvalId` |

---

## Environment-Based Network Switching

| Variable | Values | Effect |
|---|---|---|
| `DATA_MODE` | `real` / `fallback` | Controls whether real OKX APIs or demo data are used |
| `OKX_NETWORK` | `testnet` / `mainnet` | Network label shown in UI badge; OKX routes by `chainIndex` internally |
| `OKX_CHAIN` | `x-layer` / `base` / etc. | Chain used for signal discovery and swap quoting |
| `ENABLE_LIVE_EXECUTION` | `true` / `false` | Must be explicitly `true` to allow real fund movement |

**Local real-data testing:**
```
DATA_MODE=real
OKX_NETWORK=testnet
ENABLE_LIVE_EXECUTION=false
```

**Production mainnet:**
```
DATA_MODE=real
OKX_NETWORK=mainnet
ENABLE_LIVE_EXECUTION=true   # only if live swaps are intended
```

---

## OKX API Integration

PhylaX calls OKX REST APIs directly from Next.js Route Handlers (server-side only):

| Endpoint | Used for |
|---|---|
| `GET /api/v5/dex/market/signal-list` | KOL/smart-money signal discovery |
| `POST /api/v6/security/token-scan` | Honeypot / risk detection per token |
| `GET /api/v5/dex/aggregator/quote` | Swap simulation and price impact check |

Required credentials: `OKX_API_KEY`, `OKX_SECRET_KEY`, `OKX_PASSPHRASE`, `OKX_PROJECT_ID`  
Get them at: https://web3.okx.com/onchain-os/dev-portal

---

## Secret Handling

- All OKX credentials are **server-side only** — never in `NEXT_PUBLIC_*` variables
- No private keys are ever requested from the user
- `.env` is gitignored
- `approvalId` is an in-memory UUID with a 5-minute TTL — not stored in any database

---

## Source Metadata on Every Response

Every OKX-related API response includes a `meta` object:

```json
{
  "source": "okx_real" | "fallback_demo" | "okx_real_failed",
  "network": "testnet" | "mainnet",
  "chain": "x-layer",
  "timestamp": "2026-05-14T16:00:00.000Z",
  "fallbackReason": "DATA_MODE=fallback"
}
```

This is displayed in the UI header as a live badge, making data provenance transparent.
