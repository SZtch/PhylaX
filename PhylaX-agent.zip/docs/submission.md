# Hackathon Submission Notes

**Project Name**: PhylaX
**Participant ID**: 2054917885347762176

## OKX Skills Used
- `okx-dex-signal`: Sourcing KOL / Smart Money signals
- `okx-security`: Token security scanning (honeypot/risk checks)
- `okx-dex-swap`: Swap simulation and execution

## Implementation Approach
PhylaX is a wallet-gated chat-based trading assistant that provides risk intelligence
before every on-chain trade. Users connect a wallet via Privy, then interact with
PhylaX through natural-language chat to scan tokens, get swap quotes, and confirm
trades with their own wallet signature.

Rather than autonomous execution, PhylaX enforces a mandatory human-in-the-loop
approval step with user-confirmed wallet signature. The app relies heavily on the
OKX tool suite for on-chain intelligence and execution.

## Limitations
- State is kept in React component memory (lost on refresh).
- The `approval-store` uses Redis for live execution with in-memory fallback for demo mode.
- Full Privy backend token verification is abstracted but not yet fully implemented.
- PhylaX does not execute without user confirmation.
