// OKX Adapter Layer
//
// PhylaX uses a strictly real-only, fail-closed integration with the OKX Onchain OS CLI.
// All demo data, mock fallbacks, and dummy placeholders have been removed.
// If any CLI command fails or the integration is unavailable, an OkxRealModeError 
// is thrown and the system fails closed gracefully.
// Default source token for swaps: USDC on X Layer
//   0x74b7f16337b8972027f6196a17a631ac6de26d22

import { TokenSignal, SimulationResult, SourceMeta } from "./schemas";
import { runCli, OkxCliError } from "./cli-runner";

import { normalizeChain, ChainConfig, DEFAULT_CHAIN } from "./chains";

// ---------------------------------------------------------------------------
// Config helpers
// ---------------------------------------------------------------------------

// Config helpers
// ---------------------------------------------------------------------------

function sourceMeta(
  src: SourceMeta["source"],
  chainConfig: ChainConfig
): SourceMeta {
  return {
    source: src,
    provider: "OKX Onchain OS",
    chainIndex: chainConfig.chainIndex,
    chainName: chainConfig.name,
    chainSlug: chainConfig.chainSlug,
    timestamp: new Date().toISOString(),
  };
}

// ---------------------------------------------------------------------------
// Error type — thrown in production mode on any CLI failure
// ---------------------------------------------------------------------------

export class OkxRealModeError extends Error {
  public readonly meta: SourceMeta;
  constructor(message: string, chainConfig: ChainConfig = DEFAULT_CHAIN) {
    super(message);
    this.name = "OkxRealModeError";
    this.meta = sourceMeta("okx_real_failed", chainConfig);
  }
}

// ---------------------------------------------------------------------------
// Internal helper: unwrap CLI JSON result safely
// ---------------------------------------------------------------------------

function unwrapCliResult(raw: unknown, cmdLabel: string, chainConfig: ChainConfig = DEFAULT_CHAIN): unknown[] {
  if (typeof raw !== "object" || raw === null) {
    throw new OkxRealModeError(`Unexpected CLI output for ${cmdLabel}`, chainConfig);
  }
  const obj = raw as Record<string, unknown>;
  if (obj.ok === false) {
    throw new OkxRealModeError(`onchainos ${cmdLabel} returned ok:false`, chainConfig);
  }
  const data = obj.data;
  if (!Array.isArray(data)) {
    return [];
  }
  return data;
}

// ---------------------------------------------------------------------------
// 1. Signals — onchainos signal list
// ---------------------------------------------------------------------------

export interface SignalResponse {
  signals: TokenSignal[];
  meta: SourceMeta;
}

export async function getSignals(
  chain: string,
  maxTokens: number
): Promise<SignalResponse> {
  const chainConfig = normalizeChain(chain);
  try {
    const raw = await runCli([
      "signal", "list",
      "--chain", chainConfig.chainIndex,
      "--limit", String(maxTokens),
    ]);

    const items = unwrapCliResult(raw, "signal list", chainConfig);

    const signals: TokenSignal[] = items
      .slice(0, maxTokens)
      .map((item) => {
        const it = item as Record<string, unknown>;
        const token = (it.token ?? {}) as Record<string, unknown>;
        return {
          symbol: String(token.symbol ?? "UNKNOWN"),
          address: String(token.tokenAddress ?? ""),
          amountUsd: parseFloat(String(it.amountUsd ?? "0")),
          triggerCount: parseInt(String(it.triggerWalletCount ?? "1"), 10),
          price: String(it.price ?? "0"),
          source: "okx-dex-signal",
        } satisfies TokenSignal;
      })
      .filter((s) => s.address.length > 0);

    return { signals, meta: sourceMeta("okx_real", chainConfig) };
  } catch (err) {
    if (err instanceof OkxRealModeError) throw err;
    if (err instanceof OkxCliError) {
      throw new OkxRealModeError(
        `onchainos signal list failed: ${err.message}`, chainConfig
      );
    }
    throw new OkxRealModeError("Signal fetch failed", chainConfig);
  }
}

// ---------------------------------------------------------------------------
// 2. Token search — onchainos token search
// ---------------------------------------------------------------------------

export interface TokenSearchResult {
  symbol: string;
  address: string;
  chainIndex: string;
}

export async function searchToken(
  query: string,
  chain: string
): Promise<TokenSearchResult[]> {
  if (typeof global !== "undefined" && (global as any).__mockSearchTokenHandler) {
    return (global as any).__mockSearchTokenHandler(query, chain);
  }
  const chainConfig = normalizeChain(chain);
  try {
    const raw = await runCli([
      "token", "search",
      "--query", query,
      "--chains", chainConfig.chainSlug,
      "--limit", "5",
    ]);
    const items = unwrapCliResult(raw, "token search", chainConfig);
    return items.map((item) => {
      const it = item as Record<string, unknown>;
      return {
        symbol: String(it.symbol ?? ""),
        address: String(it.tokenContractAddress ?? it.tokenAddress ?? ""),
        chainIndex: String(it.chainIndex ?? chainConfig.chainIndex),
      };
    });
  } catch (err) {
    if (err instanceof OkxRealModeError) throw err;
    if (err instanceof OkxCliError) {
      throw new OkxRealModeError(`onchainos token search failed: ${err.message}`, chainConfig);
    }
    throw new OkxRealModeError("Token search failed", chainConfig);
  }
}

// ---------------------------------------------------------------------------
// 3. Security scan — onchainos security token-scan
// ---------------------------------------------------------------------------

export interface ScanResponse {
  riskLevel: string;
  decision: "safe" | "high_risk" | "unknown";
  executionAllowed: boolean;
  isScanned: boolean;
  isHoneypot: boolean;
  triggeredLabels: string[];
  unknownReason?: string;
  meta: SourceMeta;
}

const LABEL_FIELDS: Array<[string, string]> = [
  ["isHoneypot", "Honeypot"],
  ["isRubbishAirdrop", "Garbage Airdrop"],
  ["isAirdropScam", "Gas Mint Scam"],
  ["isLowLiquidity", "Low Liquidity"],
  ["isDumping", "Dumping"],
  ["isLiquidityRemoval", "Liquidity Removal"],
  ["isPump", "Pump"],
  ["isWash", "Wash Trading"],
  ["isFakeLiquidity", "Fake Liquidity"],
  ["isFundLinkage", "Rugpull Gang"],
  ["isCounterfeit", "Counterfeit"],
  ["isNotOpenSource", "Not Open Source"],
  ["isMintable", "Mintable"],
  ["isNotRenounced", "Not Renounced"],
];

export async function scanToken(
  address: string,
  chain: string
): Promise<ScanResponse> {
  const chainConfig = normalizeChain(chain);

  const lowerAddress = address ? address.toLowerCase() : "";

  // Native tokens and verified stablecoins (USDC/USDT) do not need security scanning
  const trustedAddresses = [
    "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", // Native
    "0x74b7f16337b8972027f6196a17a631ac6de26d22", // USDC X Layer
    "0x1e4a5963abfd975d8c9021ce480b42188849d41d", // USDT X Layer
    "0x5a77f1443d16ee5761d310e38b62f77f726bc71c", // WETH X Layer
    "0x8f8526dbfd6e38e3d8307702ca8469bae6c56c15"  // WBTC X Layer
  ];

  if (!address || trustedAddresses.includes(lowerAddress)) {
    return {
      riskLevel: "LOW",
      decision: "safe",
      executionAllowed: true,
      isScanned: true,
      isHoneypot: false,
      triggeredLabels: [],
      meta: sourceMeta("okx_real", chainConfig),
    };
  }

  try {
    const raw = await runCli([
      "security", "token-scan",
      "--chain", chainConfig.chainIndex,
      "--address", lowerAddress,
    ]);

    const items = unwrapCliResult(raw, "security token-scan");

    // Empty data array → Unknown / Watchlist
    if (items.length === 0) {
      return {
        riskLevel: "unknown",
        decision: "unknown",
        executionAllowed: false,
        isScanned: true,
        isHoneypot: false,
        triggeredLabels: [],
        unknownReason: "OKX token scan returned no security details",
        meta: sourceMeta("okx_real", chainConfig),
      };
    }

    const result = items[0] as Record<string, unknown>;
    const rawRisk = String(result.riskLevel ?? "");
    const isHoneypot = result.isHoneypot === true;

    const riskLevel = ["CRITICAL", "HIGH", "MEDIUM", "LOW"].includes(rawRisk)
      ? rawRisk
      : "HIGH";

    const triggeredLabels = LABEL_FIELDS
      .filter(([f]) => result[f] === true)
      .map(([, label]) => label);

    // P0 Phase 9: Only LOW is safe. MEDIUM/HIGH/CRITICAL all block execution.
    const isBlocked = riskLevel !== "LOW";
    return {
      riskLevel,
      decision: isBlocked ? "high_risk" : "safe",
      executionAllowed: !isBlocked,
      isScanned: true,
      isHoneypot,
      triggeredLabels,
      meta: sourceMeta("okx_real", chainConfig),
    };
  } catch (err) {
    if (err instanceof OkxRealModeError) throw err;
    if (err instanceof OkxCliError) {
      throw new OkxRealModeError(`onchainos security token-scan failed: ${err.message}`, chainConfig);
    }
    throw new OkxRealModeError("Security scan failed", chainConfig);
  }
}

// ---------------------------------------------------------------------------
// 4. Swap quote / preflight — onchainos swap quote (real only)
// ---------------------------------------------------------------------------

export interface QuotePreflightResponse {
  quote: SimulationResult;
  fromToken: string;
  fromSymbol: string;
  toSymbol: string;
  meta: SourceMeta;
}

export async function getQuotePreflight(
  toAddress: string,
  amount: number,
  chain: string,
  fromToken?: string,
  fromSymbol?: string
): Promise<QuotePreflightResponse & { fromAmountUsd: number }> {
  const chainConfig = normalizeChain(chain);
  const resolvedFromToken = fromToken || chainConfig.defaultFromToken;
  const resolvedFromSymbol = fromSymbol || chainConfig.defaultFromSymbol;

  if (typeof global !== "undefined" && (global as any).__mockGetQuotePreflightHandler) {
    return (global as any).__mockGetQuotePreflightHandler(toAddress, amount, chain, resolvedFromToken, resolvedFromSymbol);
  }

  try {
    const readableAmount = String(amount);

    const raw = await runCli([
      "swap", "quote",
      "--from",            resolvedFromToken.toLowerCase(),
      "--to",              toAddress.toLowerCase(),
      "--readable-amount", readableAmount,
      "--chain",           chainConfig.chainSlug,
    ]);

    const items = unwrapCliResult(raw, "swap quote");

    if (items.length === 0) {
      throw new OkxRealModeError(
        "OKX swap quote returned no data — token may have no liquidity or no route available", chainConfig
      );
    }

    const quote = items[0] as Record<string, unknown>;
    const txNode = (quote.tx ?? {}) as Record<string, unknown>;
    
    // Slippage / Price Impact
    const priceImpact = parseFloat(
      String(quote.priceImpactPercentage ?? quote.price_impact_percentage ?? quote.priceImpact ?? quote.price_impact ?? txNode.priceImpactPercentage ?? "0")
    );

    const toAmountRaw = parseFloat(String(quote.toTokenAmount ?? quote.to_token_amount ?? "0"));
    const toToken = (quote.toToken ?? quote.to_token ?? {}) as Record<string, unknown>;
    const toSymbol = String(toToken.tokenSymbol ?? toToken.symbol ?? "UNKNOWN");
    const toDecimalsRaw = toToken.decimal ?? toToken.decimals;
    const toUnitPriceRaw = toToken.tokenUnitPrice ?? toToken.unit_price;
    if (toDecimalsRaw === undefined || toUnitPriceRaw === undefined) {
      throw new OkxRealModeError("Missing token price or decimals in OKX quote response. Quote blocked.", chainConfig);
    }
    const toDecimals = parseInt(String(toDecimalsRaw), 10);
    const toUnitPrice = parseFloat(String(toUnitPriceRaw));
    if (isNaN(toDecimals) || isNaN(toUnitPrice) || toUnitPrice <= 0) {
      throw new OkxRealModeError("Invalid token price or decimals in OKX quote response. Quote blocked.", chainConfig);
    }
    const toAmountUsd = (toAmountRaw / Math.pow(10, toDecimals)) * toUnitPrice;

    const fromTokenNode = (quote.fromToken ?? quote.from_token ?? {}) as Record<string, unknown>;
    const fromUnitPriceRaw = fromTokenNode.tokenUnitPrice ?? fromTokenNode.unit_price;
    if (fromUnitPriceRaw === undefined) {
      throw new OkxRealModeError("Missing fromToken price in OKX quote response. Quote blocked.", chainConfig);
    }
    const fromUnitPrice = parseFloat(String(fromUnitPriceRaw));
    if (isNaN(fromUnitPrice) || fromUnitPrice <= 0) {
      throw new OkxRealModeError("Invalid fromToken price in OKX quote response. Quote blocked.", chainConfig);
    }
    const fromAmountUsd = amount * fromUnitPrice;

    // Gas Fee Calculation with Auto-Detection of Units (Wei, Gwei, Native)
    let gasFeeUsd = undefined;
    const nativePrice = parseFloat(String(quote.nativeTokenPrice ?? String(chainConfig.nativeFallbackPrice))); // fallback: chain-specific native token price (not ETH hardcoded)
    
    // Strategy 1: Direct estimateGasFee (often in Wei, Gwei, or Native)
    if (quote.estimateGasFee || quote.estimatedGasFee) {
        const rawGasFee = parseFloat(String(quote.estimateGasFee ?? quote.estimatedGasFee));
        if (!isNaN(rawGasFee) && rawGasFee > 0) {
            let gasFeeNative = rawGasFee;
            if (rawGasFee > 1e12) {
                // Returned in Wei (convert to native)
                gasFeeNative = rawGasFee * 1e-18;
            } else if (rawGasFee > 1e5) {
                // Returned in Gwei (convert to native)
                gasFeeNative = rawGasFee * 1e-9;
            }
            gasFeeUsd = gasFeeNative * nativePrice;
        }
    }
    
    // Strategy 2: Calculate from gasLimit and gasPrice
    if (gasFeeUsd === undefined) {
        const gasLimit = parseFloat(String(quote.estimatedGas ?? quote.estimated_gas ?? txNode.gasLimit ?? txNode.gas ?? "0"));
        const rawGasPrice = parseFloat(String(quote.gasPrice ?? quote.gas_price ?? txNode.gasPrice ?? "0"));
        if (rawGasPrice > 0 && gasLimit > 0) {
          let gasPriceWei = rawGasPrice;
          if (rawGasPrice > 0 && rawGasPrice < 1e6) {
              // Returned in Gwei (convert to Wei)
              gasPriceWei = rawGasPrice * 1e9;
          }
          gasFeeUsd = (gasLimit * gasPriceWei * 1e-18) * nativePrice;
        }
    }

    const compareList = quote.quoteCompareList ?? quote.quote_compare_list;
    const routeName = Array.isArray(compareList) && compareList.length > 0
      ? String((compareList[0] as Record<string, unknown>).dexName ?? "OKX DEX Aggregator")
      : "OKX DEX Aggregator";

    return {
      quote: {
        success: true,
        expectedOutputUsd: toAmountUsd > 0 ? toAmountUsd : fromAmountUsd * 0.99,
        slippage: isNaN(priceImpact) ? 0 : priceImpact,
        gasFeeUsd: gasFeeUsd ?? 0,
        route: routeName,
      },
      fromAmountUsd,
      fromToken: resolvedFromToken,
      fromSymbol: resolvedFromSymbol,
      toSymbol,
      meta: sourceMeta("okx_real", chainConfig),
    };
  } catch (err) {
    if (err instanceof OkxRealModeError) throw err;
    if (err instanceof OkxCliError) {
      throw new OkxRealModeError(`onchainos swap quote failed: ${err.message}`, chainConfig);
    }
    throw new OkxRealModeError("Swap quote failed", chainConfig);
  }
}

// ---------------------------------------------------------------------------
// LEGACY ALIAS: simulateSwap → getQuotePreflight
// Maintains backward compatibility with /api/simulate route
// ---------------------------------------------------------------------------
export async function simulateSwap(
  toAddress: string,
  amount: number,
  chain: string,
  fromToken?: string,
  fromSymbol?: string
) {
  const result = await getQuotePreflight(toAddress, amount, chain, fromToken, fromSymbol);
  return {
    simulation: result.quote,
    fromToken: result.fromToken,
    fromSymbol: result.fromSymbol,
    fromAmountUsd: result.fromAmountUsd,
    meta: result.meta,
  };
}

// ---------------------------------------------------------------------------
// 5. Swap build-tx — get unsigned transaction calldata for wallet signing
// ---------------------------------------------------------------------------

export interface SwapTxData {
  to: string;
  data: string;
  value: string;
  gas?: string;
  gasLimit?: string;
  gasPrice?: string;
  maxFeePerGas?: string;
  maxPriorityFeePerGas?: string;
}

export interface SwapBuildTxResponse {
  txData: SwapTxData | null;
  error: string | null;
  meta: SourceMeta;
}

/**
 * Get swap transaction calldata from OKX.
 *
 * Uses `onchainos swap swap` to get the actual transaction data
 * (to, data, value, gas) that the user's wallet will sign.
 *
 * If the CLI returns no data, returns null txData with a clear error.
 * Server NEVER broadcasts — this data is returned to the client for signing.
 */
export async function getSwapTxData(
  toAddress: string,
  amount: number,
  chain: string,
  walletAddress: string,
  fromToken?: string,
  slippagePercent = 1
): Promise<SwapBuildTxResponse> {
  const chainConfig = normalizeChain(chain);
  const resolvedFromToken = fromToken || chainConfig.defaultFromToken;

  if (typeof global !== "undefined" && (global as any).__mockGetSwapTxData) {
    return (global as any).__mockGetSwapTxData(toAddress, amount, chain, walletAddress, resolvedFromToken, slippagePercent);
  }
  
  const readableAmount = String(amount);

  try {
    const raw = await runCli([
      "swap", "swap",
      "--from",            resolvedFromToken.toLowerCase(),
      "--to",              toAddress.toLowerCase(),
      "--readable-amount", readableAmount,
      "--chain",           chainConfig.chainSlug,
      "--wallet",          walletAddress.toLowerCase(),
      "--slippage",        String(slippagePercent),
    ]);

    const items = unwrapCliResult(raw, "swap swap");

    if (items.length === 0) {
      return {
        txData: null,
        error:
          "OKX swap returned no data — token may have no liquidity " +
          "or no route available for this amount.",
        meta: sourceMeta("okx_real", chainConfig),
      };
    }

    const tx = items[0] as Record<string, unknown>;
    const nested = (tx.tx ?? {}) as Record<string, unknown>;

    // Extract the tx fields from OKX response
    const to = String(tx.to ?? nested.to ?? "");
    const data = String(tx.data ?? nested.data ?? "");
    const value = String(tx.value ?? nested.value ?? "0x0");
    const gas = tx.gas ?? tx.gasLimit ?? nested.gas ?? nested.gasLimit;
    const gasPrice = tx.gasPrice ?? nested.gasPrice;
    const maxFeePerGas = tx.maxFeePerGas ?? nested.maxFeePerGas;
    const maxPriorityFeePerGas = tx.maxPriorityFeePerGas ?? nested.maxPriorityFeePerGas;

    if (!to || !data) {
      return {
        txData: null,
        error:
          "OKX swap response missing transaction calldata (to/data fields). " +
          "Direct OKX DEX REST API may be required.",
        meta: sourceMeta("okx_real", chainConfig),
      };
    }

    return {
      txData: {
        to,
        data,
        value,
        gas: gas ? String(gas) : undefined,
        gasLimit: gas ? String(gas) : undefined,
        gasPrice: gasPrice ? String(gasPrice) : undefined,
        maxFeePerGas: maxFeePerGas ? String(maxFeePerGas) : undefined,
        maxPriorityFeePerGas: maxPriorityFeePerGas ? String(maxPriorityFeePerGas) : undefined,
      },
      error: null,
      meta: sourceMeta("okx_real", chainConfig),
    };
  } catch (err) {
    if (err instanceof OkxRealModeError) {
      return {
        txData: null,
        error: err.message,
        meta: sourceMeta("okx_real_failed", chainConfig),
      };
    }
    if (err instanceof OkxCliError) {
      return {
        txData: null,
        error:
          `OKX CLI swap failed: ${err.message}. ` +
          "Check token liquidity and chain availability.",
        meta: sourceMeta("okx_real_failed", chainConfig),
      };
    }
    return {
      txData: null,
      error: `Swap transaction build failed: ${err instanceof Error ? err.message : String(err)}`,
      meta: sourceMeta("okx_real_failed", chainConfig),
    };
  }
}

export function toMinimalUnits(readableAmount: number | string, decimals: number): string {
  if (typeof readableAmount === "number" && (isNaN(readableAmount) || readableAmount < 0 || !isFinite(readableAmount))) {
    throw new Error("Invalid token amount");
  }
  const numStr = String(readableAmount).trim();
  if (numStr === "" || numStr.includes('e')) {
    throw new Error("Amount notation not supported or empty");
  }
  let parts = numStr.split('.');
  let intPart = parts[0];
  let decPart = parts[1] || "";
  if (decPart.length > decimals) {
    decPart = decPart.slice(0, decimals);
  }
  const paddedDecPart = decPart.padEnd(decimals, "0");
  return intPart + paddedDecPart;
}

export async function checkAllowance(
  chain: string,
  walletAddress: string,
  tokenAddress: string,
  readableAmount: number,
  decimals: number = 18
): Promise<{ hasSufficient: boolean; allowance: string; meta: SourceMeta }> {
  const chainConfig = normalizeChain(chain);
  
  if (typeof global !== "undefined" && (global as any).__mockCheckAllowance) {
    return (global as any).__mockCheckAllowance(chain, walletAddress, tokenAddress, readableAmount, decimals);
  }

  try {
    const raw = await runCli([
      "swap", "check-approvals",
      "--chain", chainConfig.chainSlug,
      "--address", walletAddress.toLowerCase(),
      "--token", tokenAddress.toLowerCase()
    ]);
    const items = unwrapCliResult(raw, "swap check-approvals");
    if (items.length === 0) {
      return { hasSufficient: false, allowance: "0", meta: sourceMeta("okx_real", chainConfig) };
    }
    const result = items[0] as Record<string, unknown>;
    const allowance = String(result.allowance ?? "0");
    
    let needed = "0";
    try {
      needed = toMinimalUnits(readableAmount, decimals);
    } catch {
      return { hasSufficient: false, allowance: "0", meta: sourceMeta("okx_real_failed", chainConfig) };
    }
    
    let hasSufficient = false;
    try {
      hasSufficient = BigInt(allowance) >= BigInt(needed);
    } catch {
      hasSufficient = false;
    }

    return {
      hasSufficient,
      allowance,
      meta: sourceMeta("okx_real", chainConfig)
    };
  } catch (err) {
    return { hasSufficient: false, allowance: "0", meta: sourceMeta("okx_real_failed", chainConfig) };
  }
}

export async function checkBalance(
  chain: string,
  walletAddress: string,
  tokenAddress: string,
  readableAmount: number | string
): Promise<{ hasSufficient: boolean; balance: string; meta: SourceMeta }> {
  if (typeof global !== "undefined" && (global as any).__mockCheckBalance) {
    return (global as any).__mockCheckBalance(chain, walletAddress, tokenAddress, readableAmount);
  }
  const chainConfig = normalizeChain(chain);

  // Native token is passed as empty address, so for OKX portfolio we use just "chainIndex:"
  const isNativeToken = !tokenAddress || tokenAddress.toLowerCase() === "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee";
  const resolvedToken = isNativeToken ? "" : tokenAddress.toLowerCase();
  const tokenArg = `${chainConfig.chainIndex}:${resolvedToken}`;

  try {
    let balanceStr = "0";
    let decimals = 18;

    if (isNativeToken) {
      // Use viem for native token balance
      const { createPublicClient, http, formatUnits } = await import("viem");
      const client = createPublicClient({ transport: http("https://rpc.xlayer.tech") });
      const bal = await client.getBalance({ address: walletAddress as `0x${string}` });
      balanceStr = formatUnits(bal, 18);
    } else {
      const raw = await runCli([
        "portfolio", "token-balances",
        "--address", walletAddress.toLowerCase(),
        "--tokens", tokenArg
      ]);
      const items = unwrapCliResult(raw, "portfolio token-balances");
      if (items.length > 0) {
        const result = items[0] as Record<string, unknown>;
        balanceStr = String(result.balance ?? result.amount ?? "0");
        const decimalsRaw = result.decimal ?? result.decimals;
        if (decimalsRaw !== undefined) {
          decimals = parseInt(String(decimalsRaw), 10);
        }
      } else {
         return { hasSufficient: false, balance: "0", meta: sourceMeta("okx_real", chainConfig) };
      }
    }
    let hasSufficient = false;
    try {
      const balanceMinimal = toMinimalUnits(balanceStr, decimals);
      const neededMinimal = toMinimalUnits(readableAmount, decimals);
      hasSufficient = BigInt(balanceMinimal) >= BigInt(neededMinimal);
    } catch {
      hasSufficient = false;
    }
    
    return {
      hasSufficient,
      balance: balanceStr,
      meta: sourceMeta("okx_real", chainConfig)
    };
  } catch (err) {
    return { hasSufficient: false, balance: "0", meta: sourceMeta("okx_real_failed", chainConfig) };
  }
}

export async function getApproveTxData(
  chain: string,
  tokenAddress: string,
  readableAmount: number,
  decimals: number
): Promise<{ txData: SwapTxData | null; error: string | null; meta: SourceMeta }> {
  const chainConfig = normalizeChain(chain);
  
  if (typeof global !== "undefined" && (global as any).__mockGetApproveTxData) {
    return (global as any).__mockGetApproveTxData(chain, tokenAddress, readableAmount, decimals);
  }

  // Convert to minimal units
  let minimalUnits = "0";
  if (readableAmount > 0) {
    try {
      minimalUnits = toMinimalUnits(readableAmount, decimals);
    } catch (err: any) {
      return { txData: null, error: err.message, meta: sourceMeta("okx_real_failed", chainConfig) };
    }
  }

  try {
    const raw = await runCli([
      "swap", "approve",
      "--chain", chainConfig.chainSlug,
      "--token", tokenAddress.toLowerCase(),
      "--amount", minimalUnits
    ]);
    const items = unwrapCliResult(raw, "swap approve");
    if (items.length === 0) {
      return { txData: null, error: "Failed to get approve tx data", meta: sourceMeta("okx_real", chainConfig) };
    }
    const result = items[0] as Record<string, unknown>;
    const tx = (result.tx ?? result) as Record<string, unknown>;
    
    return {
      txData: {
        to: String(tx.to ?? ""),
        data: String(tx.data ?? ""),
        value: String(tx.value ?? "0x0"),
        gas: tx.gas ? String(tx.gas) : undefined,
        gasLimit: tx.gasLimit ? String(tx.gasLimit) : undefined,
        gasPrice: tx.gasPrice ? String(tx.gasPrice) : undefined,
      },
      error: null,
      meta: sourceMeta("okx_real", chainConfig)
    };
  } catch (err) {
    return {
      txData: null,
      error: `Approve transaction build failed: ${err instanceof Error ? err.message : String(err)}`,
      meta: sourceMeta("okx_real_failed", chainConfig)
    };
  }
}

export async function getTokenDecimals(chain: string, tokenAddress: string): Promise<number> {
  const chainConfig = normalizeChain(chain);
  if (!tokenAddress || tokenAddress === "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee") return 18;
  const tokenArg = `${chainConfig.chainIndex}:${tokenAddress.toLowerCase()}`;
  try {
    const priceRaw = await runCli(["market", "price-info", "--tokens", tokenArg]);
    const items = unwrapCliResult(priceRaw, "market price-info", chainConfig);
    if (items.length > 0) {
      const info = items[0] as Record<string, unknown>;
      const decimals = info.decimal ?? info.decimals;
      if (decimals !== undefined) return parseInt(String(decimals), 10);
    }
  } catch {}
  throw new OkxRealModeError(`Unable to determine decimals for token ${tokenAddress} on ${chain}.`, chainConfig);
}
