import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Allow all common ngrok domains to bypass Next.js security blocks during local testing
  experimental: {
    serverActions: {
      allowedOrigins: [
        "localhost:3000",
        "expediential-derangeable-cordie.ngrok-free.dev",
        "*.ngrok-free.app",
        "*.ngrok.app",
        "*.ngrok-free.dev",
        "*.ngrok.io",
      ],
    },
  },
};

export default nextConfig;